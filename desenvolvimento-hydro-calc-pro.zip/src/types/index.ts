export type FrictionMethod = "colebrook" | "swamee-jain"

export type FlowRegime = "laminar" | "transicao" | "turbulento" | "estatico"

export type AlertLevel = "ok" | "atencao" | "critico"

export type CavitationStatus = "seguro" | "limitrofe" | "incompativel"

export interface Fluid {
  id?: string
  nome: string
  temperaturaC: number
  /** Massa específica [kg/m³] */
  rho: number
  /** Viscosidade dinâmica [Pa·s] */
  mu: number
  /** Pressão de vapor [kPa abs] */
  pv: number
  fonte: string
}

export interface Material {
  id?: string
  nome: string
  /** Rugosidade absoluta [mm] */
  epsilon: number
  fonte: string
}

export interface Singularity {
  nome: string
  quantidade: number
  kUnitario: number
}

export interface PipeSection {
  diametroMm: number
  comprimentoM: number
  /** Rugosidade absoluta [mm] (preenchida a partir do material ou digitada) */
  materialOuEpsilonMm: number
  materialNome?: string
  singularidades: Singularity[]
}

export interface SystemInput {
  fluido: Fluid
  vazaoM3h: number
  p0KPaAbs: number
  p2KPaAbs: number
  z0: number
  z2: number
  zBomba: number
  succao: PipeSection
  recalque: PipeSection
  /** Rendimento da bomba (0–1] */
  etaBomba: number
  /** Rendimento do motor (0–1] */
  etaMotor: number
  npshr: number
  horasDia: number
  diasMes: number
  tarifaKWh: number
  g: number
  metodoAtrito: FrictionMethod
}

export interface SystemAlert {
  nivel: AlertLevel
  mensagem: string
  grandeza: string
}

export interface FrictionResult {
  f: number
  iteracoes: number
  convergiu: boolean
  metodo: FrictionMethod | "laminar"
}

export interface SectionResult {
  diametroM: number
  areaM2: number
  velocidade: number
  cargaCinetica: number
  reynolds: number
  regime: FlowRegime
  rugosidadeRelativa: number
  atrito: FrictionResult
  somaK: number
  perdaDistribuida: number
  perdaLocalizada: number
  perdaTotal: number
}

export interface HeadComposition {
  pressao: number
  desnivel: number
  perdaSuccao: number
  perdaRecalque: number
  total: number
}

export interface NpshTerms {
  pressaoReservatorio: number
  pressaoVapor: number
  alturaGeometrica: number
  perdaSuccao: number
}

export interface NpshResult {
  npsha: number
  npshr: number
  margem: number
  razao: number
  status: CavitationStatus
  termos: NpshTerms
}

export interface PowerResult {
  hidraulicaW: number
  eixoW: number
  eletricaW: number
  energiaMensalKWh: number
  custoMensal: number
}

export interface SystemResult {
  vazaoM3s: number
  p0Pa: number
  p2Pa: number
  pvPa: number
  succao: SectionResult
  recalque: SectionResult
  altura: HeadComposition
  potencia: PowerResult
  npsh: NpshResult
  alerts: SystemAlert[]
}

export interface Settings {
  g: number
  metodoAtrito: FrictionMethod
  limiarSeguro: number
  limiarLimitrofe: number
  vMaxSuccao: number
  vMaxRecalque: number
  reLaminar: number
  reTurbulento: number
  rugRelMax: number
}

export interface PumpCurvePoint {
  vazaoM3h: number
  alturaM: number
  /** Rendimento da bomba em % */
  etaPct: number
  npshrM: number
}

export interface Scenario {
  id: string
  nome: string
  descricao: string
  input: SystemInput
  curvaBomba: PumpCurvePoint[]
  criadoEm: string
  atualizadoEm: string
}

export interface Premise {
  id: string
  texto: string
}

export interface Reference {
  id: string
  texto: string
}

export type UnitSystem = "si" | "tecnico"

export interface AppState {
  versao: number
  nomeProjeto: string
  cenarios: Scenario[]
  cenarioAtivoId: string
  fluidos: Fluid[]
  materiais: Material[]
  configuracoes: Settings
  premissas: Premise[]
  referencias: Reference[]
  unidades: UnitSystem
}

export interface MemoryVariable {
  simbolo: string
  descricao: string
  valor: string
  unidade: string
}

export interface MemoryItem {
  grandeza: string
  equacao: string
  variaveis: MemoryVariable[]
  substituicao: string
  resultado: string
  unidade: string
}

export interface MemorySection {
  id: string
  titulo: string
  itens: MemoryItem[]
}

export interface ComparisonRow {
  chave: string
  grandeza: string
  unidade: string
  base: number
  adicional: number
  variacaoPct: number | null
}

export interface ComparisonReport {
  linhas: ComparisonRow[]
  interpretacao: string[]
}

export interface OperatingPoint {
  vazaoM3h: number
  alturaM: number
  etaPct: number
  npshrM: number
  resultado: SystemResult
}

export interface CurvePoint {
  vazaoM3h: number
  alturaSistema: number
  alturaBomba?: number
}

export type SensitivityParameter =
  | "vazao"
  | "kValvula"
  | "pressaoVapor"
  | "cotaZ0"
  | "diametroSuccao"
  | "diametroRecalque"

export interface SensitivityPoint {
  x: number
  altura: number
  potenciaEixoKW: number
  potenciaEletricaKW: number
  margemNpsh: number
  razaoNpsh: number
  valido: boolean
}

export interface SensitivityCrossing {
  limiar: number
  x: number
  rotulo: string
}
