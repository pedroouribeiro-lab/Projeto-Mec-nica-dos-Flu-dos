import type { Settings, SystemInput, SystemResult } from "@/types"
import { computeSystem, type ThresholdSettings } from "@/utils/system"
import { EngineeringInputError } from "@/utils/units"

export type CalculationOutcome =
  | { ok: true; result: SystemResult }
  | { ok: false; error: string; grandeza?: string }

export function thresholdsFromSettings(s: Settings): ThresholdSettings {
  return {
    limiarSeguro: s.limiarSeguro,
    limiarLimitrofe: s.limiarLimitrofe,
    vMaxSuccao: s.vMaxSuccao,
    vMaxRecalque: s.vMaxRecalque,
    reLaminar: s.reLaminar,
    reTurbulento: s.reTurbulento,
    rugRelMax: s.rugRelMax,
  }
}

export function runCalculation(input: SystemInput, settings: Settings): CalculationOutcome {
  try {
    return { ok: true, result: computeSystem(input, thresholdsFromSettings(settings)) }
  } catch (err) {
    if (err instanceof EngineeringInputError) {
      return { ok: false, error: err.message, grandeza: err.grandeza }
    }
    return { ok: false, error: err instanceof Error ? err.message : "Erro desconhecido no cálculo." }
  }
}

export interface FieldIssue {
  campo: string
  mensagem: string
}

/** Validação de entrada para o formulário (não lança). */
export function validateInput(input: SystemInput): FieldIssue[] {
  const issues: FieldIssue[] = []
  const pos = (v: number, campo: string, nome: string) => {
    if (!Number.isFinite(v) || v <= 0) issues.push({ campo, mensagem: `${nome} deve ser maior que zero.` })
  }
  const nonNeg = (v: number, campo: string, nome: string) => {
    if (!Number.isFinite(v) || v < 0) issues.push({ campo, mensagem: `${nome} não pode ser negativo.` })
  }
  const finite = (v: number, campo: string, nome: string) => {
    if (!Number.isFinite(v)) issues.push({ campo, mensagem: `${nome} deve ser um número válido.` })
  }
  const eta = (v: number, campo: string, nome: string) => {
    const n = v > 1 ? v / 100 : v
    if (!Number.isFinite(v) || n <= 0 || n > 1) issues.push({ campo, mensagem: `${nome} deve estar entre 0 e 1 (ou 0–100%).` })
  }

  pos(input.fluido.rho, "fluido.rho", "Massa específica")
  pos(input.fluido.mu, "fluido.mu", "Viscosidade dinâmica")
  nonNeg(input.fluido.pv, "fluido.pv", "Pressão de vapor")
  nonNeg(input.vazaoM3h, "vazaoM3h", "Vazão")
  nonNeg(input.p0KPaAbs, "p0KPaAbs", "P0 absoluta")
  nonNeg(input.p2KPaAbs, "p2KPaAbs", "P2 absoluta")
  finite(input.z0, "z0", "Cota z0")
  finite(input.z2, "z2", "Cota z2")
  finite(input.zBomba, "zBomba", "Cota da bomba")
  pos(input.succao.diametroMm, "succao.diametroMm", "Diâmetro da sucção")
  pos(input.succao.comprimentoM, "succao.comprimentoM", "Comprimento da sucção")
  nonNeg(input.succao.materialOuEpsilonMm, "succao.materialOuEpsilonMm", "Rugosidade da sucção")
  pos(input.recalque.diametroMm, "recalque.diametroMm", "Diâmetro do recalque")
  pos(input.recalque.comprimentoM, "recalque.comprimentoM", "Comprimento do recalque")
  nonNeg(input.recalque.materialOuEpsilonMm, "recalque.materialOuEpsilonMm", "Rugosidade do recalque")
  for (const [trecho, sec] of [["succao", input.succao], ["recalque", input.recalque]] as const) {
    sec.singularidades.forEach((s, i) => {
      nonNeg(s.quantidade, `${trecho}.singularidades.${i}.quantidade`, `Quantidade (${s.nome || "item"})`)
      nonNeg(s.kUnitario, `${trecho}.singularidades.${i}.kUnitario`, `K (${s.nome || "item"})`)
    })
  }
  eta(input.etaBomba, "etaBomba", "Rendimento da bomba")
  eta(input.etaMotor, "etaMotor", "Rendimento do motor")
  pos(input.npshr, "npshr", "NPSHR")
  if (!Number.isFinite(input.horasDia) || input.horasDia < 0 || input.horasDia > 24)
    issues.push({ campo: "horasDia", mensagem: "Horas por dia deve estar entre 0 e 24." })
  if (!Number.isFinite(input.diasMes) || input.diasMes < 0 || input.diasMes > 31)
    issues.push({ campo: "diasMes", mensagem: "Dias por mês deve estar entre 0 e 31." })
  nonNeg(input.tarifaKWh, "tarifaKWh", "Tarifa")
  pos(input.g, "g", "Aceleração da gravidade")
  return issues
}
