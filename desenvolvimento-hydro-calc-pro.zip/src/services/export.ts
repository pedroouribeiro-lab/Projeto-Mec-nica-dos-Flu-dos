import type { AppState, MemorySection, ComparisonReport, Scenario, SystemResult } from "@/types"
import { formatNumber as n } from "@/utils/format"
import { CAVITATION_LABEL } from "@/utils/npsh"

export function downloadText(filename: string, content: string, mime = "text/plain;charset=utf-8"): void {
  const blob = new Blob([content], { type: mime })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

function csvCell(value: string | number): string {
  const s = typeof value === "number" ? String(value).replace(".", ",") : value
  return /[;"\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
}

export function toCsv(rows: Array<Array<string | number>>): string {
  return "\uFEFF" + rows.map((r) => r.map(csvCell).join(";")).join("\n")
}

export function resultToCsv(r: SystemResult): string {
  return toCsv([
    ["Grandeza", "Valor", "Unidade"],
    ["Vazão", r.vazaoM3s, "m³/s"],
    ["V sucção", r.succao.velocidade, "m/s"],
    ["V recalque", r.recalque.velocidade, "m/s"],
    ["Re sucção", r.succao.reynolds, "-"],
    ["Re recalque", r.recalque.reynolds, "-"],
    ["f sucção", r.succao.atrito.f, "-"],
    ["f recalque", r.recalque.atrito.f, "-"],
    ["ΣK sucção", r.succao.somaK, "-"],
    ["ΣK recalque", r.recalque.somaK, "-"],
    ["hf sucção", r.succao.perdaDistribuida, "m"],
    ["hl sucção", r.succao.perdaLocalizada, "m"],
    ["h sucção", r.succao.perdaTotal, "m"],
    ["hf recalque", r.recalque.perdaDistribuida, "m"],
    ["hl recalque", r.recalque.perdaLocalizada, "m"],
    ["h recalque", r.recalque.perdaTotal, "m"],
    ["H", r.altura.total, "m"],
    ["Ph", r.potencia.hidraulicaW, "W"],
    ["Peixo", r.potencia.eixoW, "W"],
    ["Pel", r.potencia.eletricaW, "W"],
    ["Energia", r.potencia.energiaMensalKWh, "kWh/mês"],
    ["Custo", r.potencia.custoMensal, "R$/mês"],
    ["NPSHA", r.npsh.npsha, "m"],
    ["NPSHR", r.npsh.npshr, "m"],
    ["Margem", r.npsh.margem, "m"],
    ["Razão NPSHA/NPSHR", r.npsh.razao, "-"],
  ])
}

export function comparisonToCsv(c: ComparisonReport, nomeA: string, nomeB: string): string {
  return toCsv([
    ["Grandeza", "Unidade", nomeA, nomeB, "Variação (%)"],
    ...c.linhas.map((l) => [l.grandeza, l.unidade, l.base, l.adicional, l.variacaoPct ?? ""]),
  ])
}

export function memoryToMarkdown(sections: MemorySection[]): string {
  return sections
    .map((s) => {
      const items = s.itens
        .map((i) => {
          const vars = i.variaveis.length
            ? "\n" + i.variaveis.map((x) => `  - ${x.simbolo} (${x.descricao}) = ${x.valor} ${x.unidade}`).join("\n")
            : ""
          return `### ${i.grandeza}\n\n- Equação: \`${i.equacao}\`${vars ? "\n- Variáveis:" + vars : ""}\n- Substituição: \`${i.substituicao}\`\n- **Resultado: ${i.resultado} ${i.unidade}**`
        })
        .join("\n\n")
      return `## ${s.titulo}\n\n${items}`
    })
    .join("\n\n")
}

export function buildMarkdownReport(params: {
  state: AppState
  scenario: Scenario
  result: SystemResult
  memory: MemorySection[]
  comparison?: { report: ComparisonReport; nomeA: string; nomeB: string }
}): string {
  const { state, scenario, result: r, memory, comparison } = params
  const i = scenario.input
  const lines: string[] = [
    `# Relatório técnico — ${state.nomeProjeto}`,
    "",
    `Cenário: **${scenario.nome}**  `,
    `Gerado em: ${new Date().toLocaleString("pt-BR")}`,
    "",
    "## Dados de entrada",
    "",
    `- Fluido: ${i.fluido.nome} (ρ = ${n(i.fluido.rho, 1)} kg/m³; μ = ${n(i.fluido.mu, 5)} Pa·s; Pv = ${n(i.fluido.pv, 2)} kPa abs; ${n(i.fluido.temperaturaC, 1)} °C)`,
    `- Vazão: ${n(i.vazaoM3h, 2)} m³/h`,
    `- P0 = ${n(i.p0KPaAbs, 2)} kPa abs; P2 = ${n(i.p2KPaAbs, 2)} kPa abs`,
    `- z0 = ${n(i.z0, 2)} m; z2 = ${n(i.z2, 2)} m; z_bomba = ${n(i.zBomba, 2)} m`,
    `- Sucção: D = ${n(i.succao.diametroMm, 1)} mm; L = ${n(i.succao.comprimentoM, 1)} m; ε = ${n(i.succao.materialOuEpsilonMm, 4)} mm`,
    `- Recalque: D = ${n(i.recalque.diametroMm, 1)} mm; L = ${n(i.recalque.comprimentoM, 1)} m; ε = ${n(i.recalque.materialOuEpsilonMm, 4)} mm`,
    `- η bomba = ${n(i.etaBomba, 3)}; η motor = ${n(i.etaMotor, 3)}; NPSHR = ${n(i.npshr, 2)} m`,
    `- Operação: ${n(i.horasDia, 1)} h/dia × ${n(i.diasMes, 0)} dias/mês; tarifa R$ ${n(i.tarifaKWh, 2)}/kWh`,
    `- Método de atrito: ${i.metodoAtrito === "colebrook" ? "Colebrook-White" : "Swamee-Jain"}; g = ${n(i.g, 3)} m/s²`,
    "",
    "## Resultados principais",
    "",
    "| Grandeza | Valor | Unidade |",
    "|---|---:|---|",
    `| Altura manométrica | ${n(r.altura.total, 2)} | m |`,
    `| Potência hidráulica | ${n(r.potencia.hidraulicaW / 1000, 3)} | kW |`,
    `| Potência no eixo | ${n(r.potencia.eixoW / 1000, 3)} | kW |`,
    `| Potência elétrica | ${n(r.potencia.eletricaW / 1000, 3)} | kW |`,
    `| Energia mensal | ${n(r.potencia.energiaMensalKWh, 1)} | kWh/mês |`,
    `| Custo mensal | ${n(r.potencia.custoMensal, 2)} | R$/mês |`,
    `| NPSHA | ${n(r.npsh.npsha, 2)} | m |`,
    `| Margem NPSH | ${n(r.npsh.margem, 2)} | m |`,
    `| Razão NPSHA/NPSHR | ${n(r.npsh.razao, 3)} | - |`,
    "",
    `**Condição de cavitação:** ${CAVITATION_LABEL[r.npsh.status]}`,
    "",
    "## Alertas",
    "",
    ...r.alerts.map((a) => `- [${a.nivel.toUpperCase()}] ${a.mensagem}`),
    "",
    "# Memória de cálculo",
    "",
    memoryToMarkdown(memory),
  ]
  if (comparison) {
    lines.push(
      "",
      `## Comparação: ${comparison.nomeA} × ${comparison.nomeB}`,
      "",
      `| Grandeza | Unidade | ${comparison.nomeA} | ${comparison.nomeB} | Variação |`,
      "|---|---|---:|---:|---:|",
      ...comparison.report.linhas.map(
        (l) => `| ${l.grandeza} | ${l.unidade} | ${n(l.base, 4)} | ${n(l.adicional, 4)} | ${l.variacaoPct === null ? "—" : n(l.variacaoPct, 1) + "%"} |`,
      ),
      "",
      "### Interpretação",
      "",
      ...comparison.report.interpretacao.map((t) => `- ${t}`),
    )
  }
  lines.push(
    "",
    "## Premissas",
    "",
    ...state.premissas.map((p) => `- ${p.texto}`),
    "",
    "## Referências",
    "",
    ...state.referencias.map((p) => `- ${p.texto}`),
    "",
  )
  return lines.join("\n")
}
