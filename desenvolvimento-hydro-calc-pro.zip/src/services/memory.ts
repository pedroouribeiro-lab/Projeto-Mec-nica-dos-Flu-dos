import type { MemoryItem, MemorySection, PipeSection, SectionResult, SystemInput, SystemResult } from "@/types"
import { formatNumber as n, formatScientific } from "@/utils/format"
import { CAVITATION_LABEL } from "@/utils/npsh"
import { normalizeEfficiency } from "@/utils/units"

const v = (simbolo: string, descricao: string, valor: string, unidade: string) => ({ simbolo, descricao, valor, unidade })

function sectionItems(label: string, sub: string, sec: PipeSection, r: SectionResult, input: SystemInput): MemoryItem[] {
  const { rho, mu } = input.fluido
  const g = input.g
  const Q = input.vazaoM3h / 3600
  const items: MemoryItem[] = [
    {
      grandeza: `Área da seção (${label})`,
      equacao: `A${sub} = π · D${sub}² / 4`,
      variaveis: [v(`D${sub}`, "Diâmetro interno", n(r.diametroM, 4), "m")],
      substituicao: `A${sub} = π · ${n(r.diametroM, 4)}² / 4`,
      resultado: formatScientific(r.areaM2, 4),
      unidade: "m²",
    },
    {
      grandeza: `Velocidade média (${label})`,
      equacao: `V${sub} = Q / A${sub}`,
      variaveis: [v("Q", "Vazão volumétrica", n(Q, 6), "m³/s"), v(`A${sub}`, "Área", formatScientific(r.areaM2, 4), "m²")],
      substituicao: `V${sub} = ${n(Q, 6)} / ${n(r.areaM2, 6)}`,
      resultado: n(r.velocidade, 4),
      unidade: "m/s",
    },
    {
      grandeza: `Número de Reynolds (${label})`,
      equacao: `Re${sub} = ρ · V${sub} · D${sub} / μ`,
      variaveis: [
        v("ρ", "Massa específica", n(rho, 1), "kg/m³"),
        v(`V${sub}`, "Velocidade", n(r.velocidade, 4), "m/s"),
        v(`D${sub}`, "Diâmetro", n(r.diametroM, 4), "m"),
        v("μ", "Viscosidade dinâmica", n(mu, 5), "Pa·s"),
      ],
      substituicao: `Re${sub} = ${n(rho, 1)} · ${n(r.velocidade, 4)} · ${n(r.diametroM, 4)} / ${n(mu, 5)}`,
      resultado: `${n(r.reynolds, 0)} (${r.regime})`,
      unidade: "-",
    },
    {
      grandeza: `Rugosidade relativa (${label})`,
      equacao: `ε/D${sub}`,
      variaveis: [v("ε", "Rugosidade absoluta", n(sec.materialOuEpsilonMm, 4), "mm"), v(`D${sub}`, "Diâmetro", n(sec.diametroMm, 1), "mm")],
      substituicao: `ε/D${sub} = ${n(sec.materialOuEpsilonMm, 4)} / ${n(sec.diametroMm, 1)}`,
      resultado: formatScientific(r.rugosidadeRelativa, 4),
      unidade: "-",
    },
    {
      grandeza: `Fator de atrito de Darcy (${label})`,
      equacao:
        r.atrito.metodo === "laminar"
          ? `f${sub} = 64 / Re${sub}`
          : r.atrito.metodo === "swamee-jain"
            ? `f${sub} = 0,25 / [log₁₀(ε/(3,7·D) + 5,74/Re^0,9)]²`
            : `1/√f${sub} = −2 · log₁₀(ε/(3,7·D) + 2,51/(Re·√f))`,
      variaveis: [
        v(`Re${sub}`, "Reynolds", n(r.reynolds, 0), "-"),
        v("ε/D", "Rugosidade relativa", formatScientific(r.rugosidadeRelativa, 4), "-"),
      ],
      substituicao:
        r.atrito.metodo === "colebrook"
          ? `Iterativo (chute inicial Swamee-Jain), |Δf| < 10⁻¹⁰ — ${r.atrito.iteracoes} iterações${r.atrito.convergiu ? "" : " (NÃO convergiu)"}`
          : r.atrito.metodo === "laminar"
            ? `f${sub} = 64 / ${n(r.reynolds, 0)}`
            : `f${sub} = 0,25 / [log₁₀(${formatScientific(r.rugosidadeRelativa, 3)}/3,7 + 5,74/${n(r.reynolds, 0)}^0,9)]²`,
      resultado: n(r.atrito.f, 6),
      unidade: "-",
    },
    {
      grandeza: `Perda distribuída (${label})`,
      equacao: `hf${sub} = f · (L/D) · V²/(2g)`,
      variaveis: [
        v("f", "Fator de atrito", n(r.atrito.f, 6), "-"),
        v("L", "Comprimento", n(sec.comprimentoM, 2), "m"),
        v("D", "Diâmetro", n(r.diametroM, 4), "m"),
        v("V", "Velocidade", n(r.velocidade, 4), "m/s"),
        v("g", "Gravidade", n(g, 3), "m/s²"),
      ],
      substituicao: `hf${sub} = ${n(r.atrito.f, 6)} · (${n(sec.comprimentoM, 2)}/${n(r.diametroM, 4)}) · ${n(r.velocidade, 4)}²/(2·${n(g, 3)})`,
      resultado: n(r.perdaDistribuida, 4),
      unidade: "m",
    },
    {
      grandeza: `Soma dos coeficientes K (${label})`,
      equacao: `ΣK${sub} = Σ (quantidade · K)`,
      variaveis: sec.singularidades.map((s) => v(s.nome, `${s.quantidade} × ${n(s.kUnitario, 2)}`, n(s.quantidade * s.kUnitario, 2), "-")),
      substituicao: `ΣK${sub} = ${sec.singularidades.map((s) => `${s.quantidade}·${n(s.kUnitario, 2)}`).join(" + ") || "0"}`,
      resultado: n(r.somaK, 2),
      unidade: "-",
    },
    {
      grandeza: `Perda localizada (${label})`,
      equacao: `hl${sub} = ΣK · V²/(2g)`,
      variaveis: [v("ΣK", "Soma dos K", n(r.somaK, 2), "-"), v("V²/2g", "Carga cinética", n(r.cargaCinetica, 4), "m")],
      substituicao: `hl${sub} = ${n(r.somaK, 2)} · ${n(r.cargaCinetica, 4)}`,
      resultado: n(r.perdaLocalizada, 4),
      unidade: "m",
    },
    {
      grandeza: `Perda total (${label})`,
      equacao: `h${sub} = hf${sub} + hl${sub}`,
      variaveis: [],
      substituicao: `h${sub} = ${n(r.perdaDistribuida, 4)} + ${n(r.perdaLocalizada, 4)}`,
      resultado: n(r.perdaTotal, 4),
      unidade: "m",
    },
  ]
  return items
}

/** Gera a memória de cálculo completa (somente apresentação; não recalcula). */
export function buildCalculationMemory(input: SystemInput, r: SystemResult): MemorySection[] {
  const { rho } = input.fluido
  const g = input.g
  const etaB = normalizeEfficiency(input.etaBomba)
  const etaM = normalizeEfficiency(input.etaMotor)
  const pelKW = r.potencia.eletricaW / 1000
  const suc = sectionItems("sucção", "s", input.succao, r.succao, input)
  const rec = sectionItems("recalque", "r", input.recalque, r.recalque, input)

  return [
    {
      id: "hidraulica",
      titulo: "1. Hidráulica e regime",
      itens: [
        {
          grandeza: "Vazão volumétrica",
          equacao: "Q [m³/s] = Q [m³/h] / 3600",
          variaveis: [v("Q", "Vazão informada", n(input.vazaoM3h, 2), "m³/h")],
          substituicao: `Q = ${n(input.vazaoM3h, 2)} / 3600`,
          resultado: n(r.vazaoM3s, 6),
          unidade: "m³/s",
        },
        {
          grandeza: "Pressões absolutas",
          equacao: "P [Pa] = P [kPa] · 1000",
          variaveis: [
            v("P0", "Pressão no reservatório de sucção", n(input.p0KPaAbs, 2), "kPa abs"),
            v("P2", "Pressão no reservatório de descarga", n(input.p2KPaAbs, 2), "kPa abs"),
            v("Pv", "Pressão de vapor", n(input.fluido.pv, 2), "kPa abs"),
          ],
          substituicao: `P0 = ${n(r.p0Pa, 0)} Pa; P2 = ${n(r.p2Pa, 0)} Pa; Pv = ${n(r.pvPa, 0)} Pa`,
          resultado: "—",
          unidade: "Pa",
        },
        ...suc.slice(0, 4),
        ...rec.slice(0, 4),
      ],
    },
    { id: "succao", titulo: "2. Linha de sucção", itens: suc.slice(4) },
    {
      id: "recalque",
      titulo: "3. Recalque e Bernoulli",
      itens: [
        ...rec.slice(4),
        {
          grandeza: "Altura manométrica total",
          equacao: "H = (P2 − P0)/(ρ·g) + (z2 − z0) + h_s + h_r",
          variaveis: [
            v("(P2−P0)/ρg", "Parcela de pressão", n(r.altura.pressao, 4), "m"),
            v("z2 − z0", "Desnível geométrico", n(r.altura.desnivel, 3), "m"),
            v("h_s", "Perda na sucção", n(r.altura.perdaSuccao, 4), "m"),
            v("h_r", "Perda no recalque", n(r.altura.perdaRecalque, 4), "m"),
          ],
          substituicao: `H = ${n(r.altura.pressao, 4)} + ${n(r.altura.desnivel, 3)} + ${n(r.altura.perdaSuccao, 4)} + ${n(r.altura.perdaRecalque, 4)}`,
          resultado: n(r.altura.total, 3),
          unidade: "m",
        },
      ],
    },
    {
      id: "potencia",
      titulo: "4. Potência e energia",
      itens: [
        {
          grandeza: "Potência hidráulica",
          equacao: "Ph = ρ · g · Q · H",
          variaveis: [v("ρ", "Massa específica", n(rho, 1), "kg/m³"), v("Q", "Vazão", n(r.vazaoM3s, 6), "m³/s"), v("H", "Altura", n(r.altura.total, 3), "m")],
          substituicao: `Ph = ${n(rho, 1)} · ${n(g, 3)} · ${n(r.vazaoM3s, 6)} · ${n(r.altura.total, 3)}`,
          resultado: n(r.potencia.hidraulicaW, 1),
          unidade: "W",
        },
        {
          grandeza: "Potência no eixo",
          equacao: "Peixo = Ph / η_bomba",
          variaveis: [v("η_bomba", "Rendimento da bomba", n(etaB, 3), "-")],
          substituicao: `Peixo = ${n(r.potencia.hidraulicaW, 1)} / ${n(etaB, 3)}`,
          resultado: n(r.potencia.eixoW, 1),
          unidade: "W",
        },
        {
          grandeza: "Potência elétrica",
          equacao: "Pel = Peixo / η_motor",
          variaveis: [v("η_motor", "Rendimento do motor", n(etaM, 3), "-")],
          substituicao: `Pel = ${n(r.potencia.eixoW, 1)} / ${n(etaM, 3)}`,
          resultado: n(r.potencia.eletricaW, 1),
          unidade: "W",
        },
        {
          grandeza: "Energia mensal",
          equacao: "E = Pel · h/dia · dias/mês",
          variaveis: [v("h/dia", "Operação diária", n(input.horasDia, 1), "h"), v("dias", "Dias por mês", n(input.diasMes, 0), "d")],
          substituicao: `E = ${n(pelKW, 4)} · ${n(input.horasDia, 1)} · ${n(input.diasMes, 0)}`,
          resultado: n(r.potencia.energiaMensalKWh, 1),
          unidade: "kWh/mês",
        },
        {
          grandeza: "Custo mensal",
          equacao: "C = E · tarifa",
          variaveis: [v("tarifa", "Tarifa de energia", n(input.tarifaKWh, 2), "R$/kWh")],
          substituicao: `C = ${n(r.potencia.energiaMensalKWh, 1)} · ${n(input.tarifaKWh, 2)}`,
          resultado: n(r.potencia.custoMensal, 2),
          unidade: "R$/mês",
        },
      ],
    },
    {
      id: "npsh",
      titulo: "5. NPSH e segurança",
      itens: [
        {
          grandeza: "NPSH disponível",
          equacao: "NPSHA = P0/(ρg) − Pv/(ρg) + (z0 − z_bomba) − h_s",
          variaveis: [
            v("P0/ρg", "Carga de pressão no reservatório", n(r.npsh.termos.pressaoReservatorio, 4), "m"),
            v("Pv/ρg", "Carga de vapor", n(-r.npsh.termos.pressaoVapor, 4), "m"),
            v("z0 − z_b", "Altura geométrica", n(r.npsh.termos.alturaGeometrica, 3), "m"),
            v("h_s", "Perda na sucção", n(-r.npsh.termos.perdaSuccao, 4), "m"),
          ],
          substituicao: `NPSHA = ${n(r.npsh.termos.pressaoReservatorio, 4)} − ${n(-r.npsh.termos.pressaoVapor, 4)} + ${n(r.npsh.termos.alturaGeometrica, 3)} − ${n(-r.npsh.termos.perdaSuccao, 4)}`,
          resultado: n(r.npsh.npsha, 3),
          unidade: "m",
        },
        {
          grandeza: "Margem e razão",
          equacao: "Margem = NPSHA − NPSHR;  Razão = NPSHA / NPSHR",
          variaveis: [v("NPSHR", "NPSH requerido (fabricante)", n(r.npsh.npshr, 2), "m")],
          substituicao: `Margem = ${n(r.npsh.npsha, 3)} − ${n(r.npsh.npshr, 2)};  Razão = ${n(r.npsh.npsha, 3)} / ${n(r.npsh.npshr, 2)}`,
          resultado: `${n(r.npsh.margem, 3)} m;  ${n(r.npsh.razao, 3)} → ${CAVITATION_LABEL[r.npsh.status]}`,
          unidade: "",
        },
      ],
    },
  ]
}
