import type { AppState, Premise, Reference, Scenario, Settings, SystemInput } from "@/types"
import { CONFIGURACOES_PADRAO, CURVA_BOMBA_ILUSTRATIVA, criarCasoAdicional, criarCasoExemplo } from "@/data/example-case"
import { FLUIDOS_PADRAO } from "@/data/fluids"
import { MATERIAIS_PADRAO } from "@/data/materials"

export const STORAGE_KEY = "hydrocalc-pro:v1"
export const STATE_VERSION = 1

export function createId(prefix = "id"): string {
  const rand =
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID().slice(0, 8)
      : Math.random().toString(36).slice(2, 10)
  return `${prefix}-${rand}`
}

export const PREMISSAS_PADRAO: Premise[] = [
  { id: "p1", texto: "Escoamento permanente, incompressível e isotérmico." },
  { id: "p2", texto: "Velocidades nas superfícies livres dos reservatórios desprezíveis." },
  { id: "p3", texto: "Pressões P0 e P2 informadas em valor absoluto (kPa abs)." },
  { id: "p4", texto: "Fator de atrito de Darcy; laminar f = 64/Re para Re < 2300." },
  { id: "p5", texto: "Coeficientes K de singularidades conforme catálogo de referência; confirmar com o fabricante." },
  { id: "p6", texto: "Valores intermediários não são arredondados; arredondamento apenas na exibição." },
]

export const REFERENCIAS_PADRAO: Reference[] = [
  { id: "r1", texto: "Darcy, H.; Weisbach, J. — Equação de perda de carga distribuída hf = f·(L/D)·V²/(2g)." },
  { id: "r2", texto: "Colebrook, C. F. (1939). Turbulent flow in pipes. Journal of the ICE, 11(4), 133–156." },
  { id: "r3", texto: "Swamee, P. K.; Jain, A. K. (1976). Explicit equations for pipe-flow problems. J. Hydraulics Div. ASCE, 102(5)." },
  { id: "r4", texto: "ANSI/HI 9.6.1 — Rotodynamic Pumps: Guideline for NPSH Margin. Hydraulic Institute." },
]

function scenario(nome: string, descricao: string, input: SystemInput, id: string): Scenario {
  const agora = new Date().toISOString()
  return { id, nome, descricao, input, curvaBomba: CURVA_BOMBA_ILUSTRATIVA.map((p) => ({ ...p })), criadoEm: agora, atualizadoEm: agora }
}

export function createExampleScenario(id = createId("cen")): Scenario {
  return scenario("Condição base", "Caso de projeto: etilenoglicol 30%, Q = 30 m³/h, K válvula de controle = 10.", criarCasoExemplo(), id)
}

export function createDefaultState(): AppState {
  const base = scenario(
    "Condição base",
    "Caso de projeto: etilenoglicol 30%, Q = 30 m³/h, K válvula de controle = 10.",
    criarCasoExemplo(),
    "cen-base",
  )
  const adicional = scenario(
    "Condição adicional",
    "Mesma condição base com K da válvula de controle = 25 (válvula mais fechada).",
    criarCasoAdicional(),
    "cen-adicional",
  )
  return {
    versao: STATE_VERSION,
    nomeProjeto: "Circuito de água gelada — Bomba B-01",
    cenarios: [base, adicional],
    cenarioAtivoId: base.id,
    fluidos: FLUIDOS_PADRAO.map((f, i) => ({ ...f, id: f.id ?? `flu-${i}` })),
    materiais: MATERIAIS_PADRAO.map((m, i) => ({ ...m, id: m.id ?? `mat-${i}` })),
    configuracoes: { ...CONFIGURACOES_PADRAO },
    premissas: PREMISSAS_PADRAO.map((p) => ({ ...p })),
    referencias: REFERENCIAS_PADRAO.map((r) => ({ ...r })),
    unidades: "si",
  }
}

function isAppState(value: unknown): value is AppState {
  if (typeof value !== "object" || value === null) return false
  const v = value as Partial<AppState>
  return (
    v.versao === STATE_VERSION &&
    Array.isArray(v.cenarios) &&
    v.cenarios.length > 0 &&
    typeof v.cenarioAtivoId === "string" &&
    Array.isArray(v.fluidos) &&
    Array.isArray(v.materiais) &&
    typeof v.configuracoes === "object"
  )
}

export function loadState(): AppState {
  try {
    if (typeof window === "undefined") return createDefaultState()
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return createDefaultState()
    const parsed: unknown = JSON.parse(raw)
    if (!isAppState(parsed)) return createDefaultState()
    const defaults = createDefaultState()
    return { ...defaults, ...parsed, configuracoes: { ...defaults.configuracoes, ...parsed.configuracoes } }
  } catch {
    return createDefaultState()
  }
}

export function saveState(state: AppState): boolean {
  try {
    if (typeof window === "undefined") return false
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
    return true
  } catch {
    return false
  }
}

/** Aplica g e método de atrito globais (Premissas) à entrada do cenário. */
export function resolveInput(input: SystemInput, settings: Settings): SystemInput {
  return { ...input, g: settings.g, metodoAtrito: settings.metodoAtrito }
}

export function parseScenarioJson(text: string): Scenario | null {
  try {
    const parsed: unknown = JSON.parse(text)
    if (typeof parsed !== "object" || parsed === null) return null
    const s = parsed as Partial<Scenario>
    if (!s.input || typeof s.nome !== "string") return null
    const agora = new Date().toISOString()
    return {
      id: createId("cen"),
      nome: s.nome,
      descricao: typeof s.descricao === "string" ? s.descricao : "",
      input: s.input,
      curvaBomba: Array.isArray(s.curvaBomba) ? s.curvaBomba : [],
      criadoEm: agora,
      atualizadoEm: agora,
    }
  } catch {
    return null
  }
}
