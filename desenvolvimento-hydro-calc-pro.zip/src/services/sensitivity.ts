import type { SensitivityCrossing, SensitivityParameter, SensitivityPoint, Settings, SystemInput } from "@/types"
import { NOME_VALVULA_CONTROLE } from "@/data/example-case"
import { findCrossing, linspace } from "@/utils/interpolation"
import { computeSystem } from "@/utils/system"
import { thresholdsFromSettings } from "./calculation"

export interface SensitivityParamDef {
  id: SensitivityParameter
  rotulo: string
  unidade: string
  baseValue: (input: SystemInput) => number
  apply: (input: SystemInput, x: number) => SystemInput
  defaultRange: (base: number) => [number, number]
}

function setValveK(input: SystemInput, k: number): SystemInput {
  const idx = input.recalque.singularidades.findIndex((s) => s.nome === NOME_VALVULA_CONTROLE)
  const singularidades = [...input.recalque.singularidades]
  if (idx >= 0) singularidades[idx] = { ...singularidades[idx], kUnitario: k }
  else singularidades.push({ nome: NOME_VALVULA_CONTROLE, quantidade: 1, kUnitario: k })
  return { ...input, recalque: { ...input.recalque, singularidades } }
}

export const SENSITIVITY_PARAMS: SensitivityParamDef[] = [
  {
    id: "vazao",
    rotulo: "Vazão",
    unidade: "m³/h",
    baseValue: (i) => i.vazaoM3h,
    apply: (i, x) => ({ ...i, vazaoM3h: x }),
    defaultRange: (b) => [Math.max(b * 0.3, 0.1), b * 1.6],
  },
  {
    id: "kValvula",
    rotulo: "K da válvula de controle",
    unidade: "-",
    baseValue: (i) => i.recalque.singularidades.find((s) => s.nome === NOME_VALVULA_CONTROLE)?.kUnitario ?? 0,
    apply: setValveK,
    defaultRange: () => [0, 40],
  },
  {
    id: "pressaoVapor",
    rotulo: "Pressão de vapor",
    unidade: "kPa abs",
    baseValue: (i) => i.fluido.pv,
    apply: (i, x) => ({ ...i, fluido: { ...i.fluido, pv: x } }),
    defaultRange: (b) => [0, Math.max(b * 15, 40)],
  },
  {
    id: "cotaZ0",
    rotulo: "Cota do nível de sucção z0",
    unidade: "m",
    baseValue: (i) => i.z0,
    apply: (i, x) => ({ ...i, z0: x }),
    defaultRange: (b) => [b - 6, b + 3],
  },
  {
    id: "diametroSuccao",
    rotulo: "Diâmetro da sucção",
    unidade: "mm",
    baseValue: (i) => i.succao.diametroMm,
    apply: (i, x) => ({ ...i, succao: { ...i.succao, diametroMm: x } }),
    defaultRange: (b) => [Math.max(b * 0.5, 10), b * 1.6],
  },
  {
    id: "diametroRecalque",
    rotulo: "Diâmetro do recalque",
    unidade: "mm",
    baseValue: (i) => i.recalque.diametroMm,
    apply: (i, x) => ({ ...i, recalque: { ...i.recalque, diametroMm: x } }),
    defaultRange: (b) => [Math.max(b * 0.6, 10), b * 1.8],
  },
]

export function getSensitivityParam(id: SensitivityParameter): SensitivityParamDef {
  const def = SENSITIVITY_PARAMS.find((p) => p.id === id)
  if (!def) throw new Error(`Parâmetro de sensibilidade desconhecido: ${id}`)
  return def
}

export function runSensitivity(
  input: SystemInput,
  param: SensitivityParameter,
  min: number,
  max: number,
  settings: Settings,
  count = 41,
): { pontos: SensitivityPoint[]; cruzamentos: SensitivityCrossing[] } {
  const def = getSensitivityParam(param)
  const thresholds = thresholdsFromSettings(settings)
  const pontos: SensitivityPoint[] = linspace(min, max, count).map((x) => {
    try {
      const r = computeSystem(def.apply(input, x), thresholds)
      return {
        x,
        altura: r.altura.total,
        potenciaEixoKW: r.potencia.eixoW / 1000,
        potenciaEletricaKW: r.potencia.eletricaW / 1000,
        margemNpsh: r.npsh.margem,
        razaoNpsh: r.npsh.razao,
        valido: true,
      }
    } catch {
      return { x, altura: Number.NaN, potenciaEixoKW: Number.NaN, potenciaEletricaKW: Number.NaN, margemNpsh: Number.NaN, razaoNpsh: Number.NaN, valido: false }
    }
  })

  const validos = pontos.filter((p) => p.valido)
  const xs = validos.map((p) => p.x)
  const ys = validos.map((p) => p.razaoNpsh)
  const cruzamentos: SensitivityCrossing[] = []
  for (const [limiar, rotulo] of [
    [settings.limiarSeguro, "Razão NPSH = limiar seguro"],
    [settings.limiarLimitrofe, "Razão NPSH = 1 (NPSHA = NPSHR)"],
  ] as const) {
    const x = findCrossing(xs, ys, xs.map(() => limiar))
    if (x !== null) cruzamentos.push({ limiar, x, rotulo })
  }
  return { pontos, cruzamentos }
}
