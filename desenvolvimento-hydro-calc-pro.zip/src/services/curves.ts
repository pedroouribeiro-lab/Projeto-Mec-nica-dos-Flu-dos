import type { CurvePoint, OperatingPoint, PumpCurvePoint, Settings, SystemInput } from "@/types"
import { linearInterpolate, linspace } from "@/utils/interpolation"
import { computeSystem } from "@/utils/system"
import { thresholdsFromSettings } from "./calculation"

/** Altura do sistema H_sis(Q) [m], Q em m³/h. */
export function systemHeadAt(input: SystemInput, vazaoM3h: number, settings: Settings): number {
  return computeSystem({ ...input, vazaoM3h }, thresholdsFromSettings(settings)).altura.total
}

export function sortPumpCurve(curve: PumpCurvePoint[]): PumpCurvePoint[] {
  return [...curve]
    .filter((p) => [p.vazaoM3h, p.alturaM, p.etaPct, p.npshrM].every(Number.isFinite))
    .sort((a, b) => a.vazaoM3h - b.vazaoM3h)
}

export function pumpHeadAt(curve: PumpCurvePoint[], q: number): number | null {
  return linearInterpolate(curve.map((p) => ({ x: p.vazaoM3h, y: p.alturaM })), q)
}

export function buildCurves(
  input: SystemInput,
  pumpCurve: PumpCurvePoint[],
  settings: Settings,
  points = 41,
): CurvePoint[] {
  const sorted = sortPumpCurve(pumpCurve)
  const qMaxPump = sorted.length ? sorted[sorted.length - 1].vazaoM3h : 0
  const qMax = Math.max(qMaxPump, input.vazaoM3h * 1.5, 1)
  const xs = new Set<number>(linspace(0, qMax, points))
  sorted.forEach((p) => xs.add(p.vazaoM3h))
  return [...xs]
    .sort((a, b) => a - b)
    .map((q) => {
      const hb = sorted.length >= 2 ? pumpHeadAt(sorted, q) : null
      return {
        vazaoM3h: q,
        alturaSistema: systemHeadAt(input, q, settings),
        alturaBomba: hb ?? undefined,
      }
    })
}

/**
 * Ponto de operação: interseção H_bomba(Q) = H_sistema(Q) por bissecção
 * no domínio da curva da bomba. Retorna null se não houver interseção.
 */
export function findOperatingPoint(
  input: SystemInput,
  pumpCurve: PumpCurvePoint[],
  settings: Settings,
): OperatingPoint | null {
  const sorted = sortPumpCurve(pumpCurve)
  if (sorted.length < 2) return null
  const diff = (q: number) => (pumpHeadAt(sorted, q) ?? Number.NaN) - systemHeadAt(input, q, settings)

  const samples = linspace(sorted[0].vazaoM3h, sorted[sorted.length - 1].vazaoM3h, 200)
  let lo: number | null = null
  let hi: number | null = null
  for (let i = 0; i < samples.length - 1; i++) {
    const d0 = diff(samples[i])
    const d1 = diff(samples[i + 1])
    if (d0 === 0) {
      lo = hi = samples[i]
      break
    }
    if (d0 * d1 < 0) {
      lo = samples[i]
      hi = samples[i + 1]
      break
    }
  }
  if (lo === null || hi === null) return null

  let a = lo
  let b = hi
  for (let i = 0; i < 80 && b - a > 1e-9; i++) {
    const m = (a + b) / 2
    if (diff(a) * diff(m) <= 0) b = m
    else a = m
  }
  const q = (a + b) / 2
  const xy = (k: "etaPct" | "npshrM") => linearInterpolate(sorted.map((p) => ({ x: p.vazaoM3h, y: p[k] })), q) ?? Number.NaN
  const etaPct = xy("etaPct")
  const npshrM = xy("npshrM")
  if (!(etaPct > 0) || !(npshrM > 0)) return null

  const resultado = computeSystem(
    { ...input, vazaoM3h: q, etaBomba: etaPct / 100, npshr: npshrM },
    thresholdsFromSettings(settings),
  )
  return { vazaoM3h: q, alturaM: pumpHeadAt(sorted, q) ?? resultado.altura.total, etaPct, npshrM, resultado }
}
