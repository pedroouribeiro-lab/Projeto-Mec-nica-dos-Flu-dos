import type { Settings, SystemResult } from "@/types"
import { formatNumber } from "@/utils/format"
import { CAVITATION_LABEL, npshContributions, type NpshContribution } from "@/utils/npsh"

export interface TechnicalOpinion {
  titulo: string
  paragrafos: string[]
  contribuicoes: NpshContribution[]
}

/** Parecer técnico de cavitação citando os termos que mais pesam no NPSHA. */
export function buildTechnicalOpinion(r: SystemResult, settings: Settings): TechnicalOpinion {
  const n = r.npsh
  const contribuicoes = npshContributions(n.termos)
  const negativos = contribuicoes.filter((c) => c.valorM < 0)
  const maiorPerda = negativos[0]

  const paragrafos: string[] = [
    `NPSH disponível de ${formatNumber(n.npsha, 2)} m frente a NPSH requerido de ${formatNumber(n.npshr, 2)} m: margem de ${formatNumber(n.margem, 2)} m e razão NPSHA/NPSHR de ${formatNumber(n.razao, 2)}.`,
    `Classificação: ${CAVITATION_LABEL[n.status]} (limiares adotados: seguro ≥ ${formatNumber(settings.limiarSeguro, 2)}; limítrofe ≥ ${formatNumber(settings.limiarLimitrofe, 2)}, conforme critério de margem inspirado na ANSI/HI 9.6.1).`,
  ]

  if (maiorPerda) {
    paragrafos.push(
      `O termo que mais reduz o NPSHA é "${maiorPerda.rotulo}", com ${formatNumber(maiorPerda.valorM, 2)} m (${formatNumber(maiorPerda.pesoPct, 1)}% da soma dos módulos dos termos).`,
    )
  }

  const pressao = contribuicoes.find((c) => c.chave === "pressaoReservatorio")
  const geom = contribuicoes.find((c) => c.chave === "alturaGeometrica")
  if (pressao && geom) {
    paragrafos.push(
      `A pressão absoluta no reservatório contribui com ${formatNumber(pressao.valorM, 2)} m e a altura geométrica de sucção com ${formatNumber(geom.valorM, 2)} m${geom.valorM >= 0 ? " (sucção afogada, favorável)" : " (sucção negativa, desfavorável)"}.`,
    )
  }

  if (n.status !== "seguro") {
    paragrafos.push(
      "Recomenda-se avaliar: aumento do diâmetro da sucção, redução de singularidades a montante da bomba, elevação do nível de sucção ou redução da temperatura do fluido (menor pressão de vapor).",
    )
  }

  return { titulo: `Parecer de cavitação — ${CAVITATION_LABEL[n.status]}`, paragrafos, contribuicoes }
}
