import type { ComparisonReport, ComparisonRow, SystemResult } from "@/types"
import { percentChange } from "@/utils/interpolation"
import { CAVITATION_LABEL } from "@/utils/npsh"

interface RowDef {
  chave: string
  grandeza: string
  unidade: string
  get: (r: SystemResult) => number
}

export const COMPARISON_ROWS: RowDef[] = [
  { chave: "vSuc", grandeza: "Velocidade na sucção", unidade: "m/s", get: (r) => r.succao.velocidade },
  { chave: "vRec", grandeza: "Velocidade no recalque", unidade: "m/s", get: (r) => r.recalque.velocidade },
  { chave: "reSuc", grandeza: "Reynolds na sucção", unidade: "-", get: (r) => r.succao.reynolds },
  { chave: "reRec", grandeza: "Reynolds no recalque", unidade: "-", get: (r) => r.recalque.reynolds },
  { chave: "fSuc", grandeza: "Fator de atrito (sucção)", unidade: "-", get: (r) => r.succao.atrito.f },
  { chave: "fRec", grandeza: "Fator de atrito (recalque)", unidade: "-", get: (r) => r.recalque.atrito.f },
  { chave: "kSuc", grandeza: "ΣK sucção", unidade: "-", get: (r) => r.succao.somaK },
  { chave: "kRec", grandeza: "ΣK recalque", unidade: "-", get: (r) => r.recalque.somaK },
  { chave: "hSuc", grandeza: "Perda total na sucção", unidade: "m", get: (r) => r.succao.perdaTotal },
  { chave: "hRec", grandeza: "Perda total no recalque", unidade: "m", get: (r) => r.recalque.perdaTotal },
  { chave: "H", grandeza: "Altura manométrica", unidade: "m", get: (r) => r.altura.total },
  { chave: "Ph", grandeza: "Potência hidráulica", unidade: "kW", get: (r) => r.potencia.hidraulicaW / 1000 },
  { chave: "Peixo", grandeza: "Potência no eixo", unidade: "kW", get: (r) => r.potencia.eixoW / 1000 },
  { chave: "Pel", grandeza: "Potência elétrica", unidade: "kW", get: (r) => r.potencia.eletricaW / 1000 },
  { chave: "E", grandeza: "Energia mensal", unidade: "kWh/mês", get: (r) => r.potencia.energiaMensalKWh },
  { chave: "C", grandeza: "Custo mensal", unidade: "R$/mês", get: (r) => r.potencia.custoMensal },
  { chave: "NPSHA", grandeza: "NPSH disponível", unidade: "m", get: (r) => r.npsh.npsha },
  { chave: "NPSHR", grandeza: "NPSH requerido", unidade: "m", get: (r) => r.npsh.npshr },
  { chave: "margem", grandeza: "Margem NPSHA − NPSHR", unidade: "m", get: (r) => r.npsh.margem },
  { chave: "razao", grandeza: "Razão NPSHA/NPSHR", unidade: "-", get: (r) => r.npsh.razao },
]

function fmt(v: number, d = 2): string {
  return v.toLocaleString("pt-BR", { minimumFractionDigits: d, maximumFractionDigits: d })
}

/** Compara dois resultados e gera interpretação automática. */
export function compareResults(
  base: SystemResult,
  adicional: SystemResult,
  nomeBase = "Cenário base",
  nomeAdicional = "Cenário adicional",
): ComparisonReport {
  const linhas: ComparisonRow[] = COMPARISON_ROWS.map((d) => {
    const a = d.get(base)
    const b = d.get(adicional)
    return { chave: d.chave, grandeza: d.grandeza, unidade: d.unidade, base: a, adicional: b, variacaoPct: percentChange(a, b) }
  })

  const byKey = Object.fromEntries(linhas.map((l) => [l.chave, l]))
  const interpretacao: string[] = []

  const dK = adicional.recalque.somaK - base.recalque.somaK
  const dHrec = adicional.recalque.perdaTotal - base.recalque.perdaTotal
  if (Math.abs(dK) > 1e-9) {
    interpretacao.push(
      `${dK > 0 ? "O aumento" : "A redução"} de ΣK no recalque (${fmt(base.recalque.somaK)} → ${fmt(adicional.recalque.somaK)}) ${dHrec > 0 ? "elevou" : "reduziu"} a perda no recalque em ${fmt(Math.abs(dHrec))} m.`,
    )
  }
  const dH = adicional.altura.total - base.altura.total
  if (Math.abs(dH) > 1e-6) {
    interpretacao.push(
      `A altura manométrica ${dH > 0 ? "aumentou" : "diminuiu"} ${fmt(Math.abs(dH))} m (${fmt(Math.abs(byKey.H.variacaoPct ?? 0), 1)}%), ${dH > 0 ? "elevando" : "reduzindo"} a potência elétrica de ${fmt(base.potencia.eletricaW / 1000)} kW para ${fmt(adicional.potencia.eletricaW / 1000)} kW.`,
    )
    const dC = adicional.potencia.custoMensal - base.potencia.custoMensal
    interpretacao.push(
      `O custo mensal de energia ${dC > 0 ? "aumenta" : "diminui"} R$ ${fmt(Math.abs(dC))} (${nomeBase}: R$ ${fmt(base.potencia.custoMensal)}; ${nomeAdicional}: R$ ${fmt(adicional.potencia.custoMensal)}).`,
    )
  }
  const dNpsh = adicional.npsh.npsha - base.npsh.npsha
  const sucIgual =
    Math.abs(adicional.succao.perdaTotal - base.succao.perdaTotal) < 1e-9 &&
    Math.abs(dNpsh) < 1e-9
  if (sucIgual) {
    interpretacao.push(
      `O NPSHA permanece inalterado (${fmt(base.npsh.npsha)} m): a perda do recalque ocorre depois da bomba e não afeta a energia disponível na entrada (sucção não modificada).`,
    )
  } else {
    interpretacao.push(
      `O NPSHA ${dNpsh > 0 ? "aumentou" : "diminuiu"} ${fmt(Math.abs(dNpsh))} m (${fmt(base.npsh.npsha)} → ${fmt(adicional.npsh.npsha)} m).`,
    )
  }
  if (base.npsh.status !== adicional.npsh.status) {
    interpretacao.push(
      `A condição de cavitação muda de "${CAVITATION_LABEL[base.npsh.status]}" para "${CAVITATION_LABEL[adicional.npsh.status]}".`,
    )
  } else {
    interpretacao.push(`A condição de cavitação permanece "${CAVITATION_LABEL[base.npsh.status]}" em ambos os cenários.`)
  }

  return { linhas, interpretacao }
}
