"use client"

import { useRouter } from "next/navigation"
import { FileDown, FileJson, FileSpreadsheet, Moon, Printer, Sun } from "lucide-react"
import { useTheme } from "next-themes"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { SidebarTrigger } from "@/components/ui/sidebar"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import { useAppActions, useHydrated } from "@/hooks/use-app-store"
import { useActiveCalculation } from "@/hooks/use-calculation"
import { downloadText, resultToCsv } from "@/services/export"
import type { UnitSystem } from "@/types"

function slug(text: string): string {
  return text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .toLowerCase()
}

export function AppHeader() {
  const router = useRouter()
  const hydrated = useHydrated()
  const { state, scenario, outcome } = useActiveCalculation()
  const actions = useAppActions()
  const { resolvedTheme, setTheme } = useTheme()

  const scenarioItems = state.cenarios.map((c) => ({ value: c.id, label: c.nome }))

  function exportJson() {
    downloadText(`${slug(scenario.nome)}.json`, JSON.stringify(scenario, null, 2), "application/json")
    toast.success("Cenário exportado em JSON.")
  }

  function exportCsv() {
    if (!outcome?.ok) {
      toast.error("Corrija os dados de entrada antes de exportar.")
      return
    }
    downloadText(`${slug(scenario.nome)}-resultados.csv`, resultToCsv(outcome.result), "text/csv;charset=utf-8")
    toast.success("Resultados exportados em CSV.")
  }

  return (
    <header className="no-print sticky top-0 z-20 flex min-h-14 flex-wrap items-center gap-x-3 gap-y-2 border-b bg-background/95 px-4 py-2 backdrop-blur supports-backdrop-filter:bg-background/80 md:px-6">
      <SidebarTrigger className="-ml-1" />
      <Separator orientation="vertical" className="hidden h-6 sm:block" />
      <div className="flex min-w-0 flex-1 flex-col">
        <span className="text-xs text-muted-foreground">Projeto</span>
        <span className="truncate text-sm font-semibold">{state.nomeProjeto}</span>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <label className="sr-only" htmlFor="cenario-ativo">
          Cenário ativo
        </label>
        <Select
          items={scenarioItems}
          value={scenario.id}
          onValueChange={(v) => {
            if (typeof v === "string") actions.setActiveScenario(v)
          }}
        >
          <SelectTrigger id="cenario-ativo" className="w-44 sm:w-52" aria-label="Cenário ativo">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              {scenarioItems.map((i) => (
                <SelectItem key={i.value} value={i.value}>
                  {i.label}
                </SelectItem>
              ))}
            </SelectGroup>
          </SelectContent>
        </Select>

        <ToggleGroup
          variant="outline"
          size="sm"
          value={[state.unidades]}
          onValueChange={(v: string[]) => {
            const next = v[0] as UnitSystem | undefined
            if (next) actions.setUnits(next)
          }}
          aria-label="Sistema de unidades"
        >
          <ToggleGroupItem value="si" aria-label="Unidades SI (kW, m³/h)">
            SI
          </ToggleGroupItem>
          <ToggleGroupItem value="tecnico" aria-label="Unidades técnicas (cv, L/s)">
            cv · L/s
          </ToggleGroupItem>
        </ToggleGroup>

        <Button
          variant="ghost"
          size="icon"
          aria-label="Alternar tema claro/escuro"
          onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
        >
          {hydrated && resolvedTheme === "dark" ? <Sun /> : <Moon />}
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger render={<Button />}>
            <FileDown data-icon="inline-start" />
            Exportar relatório
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuGroup>
              <DropdownMenuLabel>{scenario.nome}</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => router.push("/relatorios?imprimir=1")}>
                <Printer />
                Exportar PDF
              </DropdownMenuItem>
            </DropdownMenuGroup>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              <DropdownMenuItem onClick={exportJson}>
                <FileJson />
                Cenário (JSON)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={exportCsv}>
                <FileSpreadsheet />
                Resultados (CSV)
              </DropdownMenuItem>
            </DropdownMenuGroup>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
