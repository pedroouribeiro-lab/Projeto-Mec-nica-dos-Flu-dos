import {
  BookOpenText,
  Calculator,
  Database,
  FileText,
  Gauge,
  Layers,
  LineChart,
  SlidersHorizontal,
  Table2,
  type LucideIcon,
} from "lucide-react"

export interface NavItem {
  href: string
  titulo: string
  icon: LucideIcon
}

export const NAV_ITEMS: NavItem[] = [
  { href: "/", titulo: "Dashboard", icon: Gauge },
  { href: "/novo-calculo", titulo: "Novo Cálculo", icon: Calculator },
  { href: "/resultados", titulo: "Resultados", icon: Table2 },
  { href: "/cenarios", titulo: "Cenários", icon: Layers },
  { href: "/curva-sistema", titulo: "Curva do Sistema", icon: LineChart },
  { href: "/sensibilidade", titulo: "Sensibilidade", icon: SlidersHorizontal },
  { href: "/banco", titulo: "Fluidos e Materiais", icon: Database },
  { href: "/relatorios", titulo: "Relatórios", icon: FileText },
  { href: "/premissas", titulo: "Premissas e Referências", icon: BookOpenText },
]
