"use client"

import Link from "next/link"
import { AlertOctagon, Calculator } from "lucide-react"
import type * as React from "react"
import { Button } from "@/components/ui/button"
import { Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty"
import { Skeleton } from "@/components/ui/skeleton"
import { useHydrated } from "@/hooks/use-app-store"
import type { CalculationOutcome } from "@/services/calculation"
import type { SystemResult } from "@/types"

export function PageSkeleton() {
  return (
    <div className="flex flex-col gap-4" aria-busy="true" aria-label="Carregando">
      <Skeleton className="h-8 w-64" />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-28" />
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Skeleton className="h-72" />
        <Skeleton className="h-72" />
      </div>
    </div>
  )
}

/** Mostra skeleton até a hidratação e um estado de erro quando o cálculo falha. */
export function ResultGuard({
  outcome,
  children,
}: {
  outcome: CalculationOutcome | null
  children: (result: SystemResult) => React.ReactNode
}) {
  const hydrated = useHydrated()
  if (!hydrated || outcome === null) return <PageSkeleton />
  if (!outcome.ok) {
    return (
      <Empty className="border">
        <EmptyHeader>
          <EmptyMedia variant="icon">
            <AlertOctagon />
          </EmptyMedia>
          <EmptyTitle>Não foi possível calcular este cenário</EmptyTitle>
          <EmptyDescription>
            {outcome.error}
            {outcome.grandeza ? ` (grandeza: ${outcome.grandeza})` : ""}
          </EmptyDescription>
        </EmptyHeader>
        <EmptyContent>
          <Button render={<Link href="/novo-calculo" />}>
            <Calculator data-icon="inline-start" />
            Revisar dados de entrada
          </Button>
        </EmptyContent>
      </Empty>
    )
  }
  return <>{children(outcome.result)}</>
}

export function HydratedOnly({ children }: { children: React.ReactNode }) {
  const hydrated = useHydrated()
  return hydrated ? <>{children}</> : <PageSkeleton />
}
