import { AlertOctagon, AlertTriangle, CheckCircle2 } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import type { AlertLevel, CavitationStatus } from "@/types"
import { CAVITATION_LABEL } from "@/utils/npsh"

export const LEVEL_FROM_CAVITATION: Record<CavitationStatus, AlertLevel> = {
  seguro: "ok",
  limitrofe: "atencao",
  incompativel: "critico",
}

export const LEVEL_LABEL: Record<AlertLevel, string> = {
  ok: "OK",
  atencao: "Atenção",
  critico: "Crítico",
}

export const LEVEL_TEXT: Record<AlertLevel, string> = {
  ok: "text-success",
  atencao: "text-warning",
  critico: "text-destructive",
}

const LEVEL_BADGE: Record<AlertLevel, string> = {
  ok: "border-success/30 bg-success/12 text-success",
  atencao: "border-warning/40 bg-warning/15 text-warning-foreground dark:text-warning",
  critico: "border-destructive/30 bg-destructive/12 text-destructive",
}

export const LEVEL_ICON = {
  ok: CheckCircle2,
  atencao: AlertTriangle,
  critico: AlertOctagon,
} as const

export function LevelBadge({ nivel, children, className }: { nivel: AlertLevel; children?: React.ReactNode; className?: string }) {
  const Icon = LEVEL_ICON[nivel]
  return (
    <Badge variant="outline" className={cn(LEVEL_BADGE[nivel], className)}>
      <Icon data-icon="inline-start" />
      {children ?? LEVEL_LABEL[nivel]}
    </Badge>
  )
}

export function CavitationBadge({ status, className }: { status: CavitationStatus; className?: string }) {
  return (
    <LevelBadge nivel={LEVEL_FROM_CAVITATION[status]} className={className}>
      {CAVITATION_LABEL[status]}
    </LevelBadge>
  )
}

/** Semáforo de três luzes; somente a luz ativa fica acesa. */
export function TrafficLight({ status }: { status: CavitationStatus }) {
  const lights: Array<{ s: CavitationStatus; on: string }> = [
    { s: "incompativel", on: "bg-destructive" },
    { s: "limitrofe", on: "bg-warning" },
    { s: "seguro", on: "bg-success" },
  ]
  return (
    <div className="flex flex-col gap-1.5 rounded-lg bg-foreground/90 p-1.5 dark:bg-black/60" role="img" aria-label={`Semáforo de cavitação: ${CAVITATION_LABEL[status]}`}>
      {lights.map((l) => (
        <span key={l.s} className={cn("size-3.5 rounded-full", l.s === status ? l.on : "bg-background/20")} />
      ))}
    </div>
  )
}
