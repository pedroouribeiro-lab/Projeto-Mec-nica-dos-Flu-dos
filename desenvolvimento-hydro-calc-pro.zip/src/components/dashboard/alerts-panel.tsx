import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import type { SystemAlert } from "@/types"
import { sortAlerts } from "@/utils/system"
import { LEVEL_ICON, LEVEL_TEXT, LevelBadge } from "./status"

export function AlertsList({ alerts }: { alerts: SystemAlert[] }) {
  const ordered = sortAlerts(alerts)
  if (ordered.length === 0) {
    return <p className="text-sm text-muted-foreground">Nenhum alerta para este cenário.</p>
  }
  return (
    <ul className="flex flex-col divide-y">
      {ordered.map((a, i) => {
        const Icon = LEVEL_ICON[a.nivel]
        return (
          <li key={`${a.grandeza}-${i}`} className="flex items-start gap-3 py-2.5 first:pt-0 last:pb-0">
            <Icon className={cn("mt-0.5 size-4 shrink-0", LEVEL_TEXT[a.nivel])} aria-hidden="true" />
            <div className="flex min-w-0 flex-1 flex-col gap-0.5">
              <span className="text-sm text-pretty">{a.mensagem}</span>
              <span className="text-xs text-muted-foreground">{a.grandeza}</span>
            </div>
            <LevelBadge nivel={a.nivel} className="shrink-0" />
          </li>
        )
      })}
    </ul>
  )
}

export function AlertsPanel({ alerts }: { alerts: SystemAlert[] }) {
  return (
    <Card className="avoid-break">
      <CardHeader>
        <CardTitle>Alertas</CardTitle>
        <CardDescription>Ordenados por gravidade</CardDescription>
      </CardHeader>
      <CardContent>
        <AlertsList alerts={alerts} />
      </CardContent>
    </Card>
  )
}
