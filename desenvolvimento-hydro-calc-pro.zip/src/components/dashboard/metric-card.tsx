import type { LucideIcon } from "lucide-react"
import type * as React from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export function MetricCard({
  titulo,
  valor,
  unidade,
  detalhe,
  icon: Icon,
  aside,
}: {
  titulo: string
  valor: string
  unidade: string
  detalhe?: React.ReactNode
  icon: LucideIcon
  aside?: React.ReactNode
}) {
  return (
    <Card size="sm" className="avoid-break">
      <CardHeader>
        <CardDescription className="flex items-center gap-2">
          <Icon className="size-4 text-primary" aria-hidden="true" />
          {titulo}
        </CardDescription>
        <CardTitle className="flex items-baseline gap-1.5">
          <span className="num text-2xl font-semibold tracking-tight">{valor}</span>
          <span className="text-sm font-normal text-muted-foreground">{unidade}</span>
        </CardTitle>
      </CardHeader>
      {detalhe || aside ? (
        <CardContent className="flex items-end justify-between gap-2 text-xs text-muted-foreground">
          <div className="flex flex-col gap-1">{detalhe}</div>
          {aside}
        </CardContent>
      ) : null}
    </Card>
  )
}
