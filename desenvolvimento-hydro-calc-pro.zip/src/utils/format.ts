const cache = new Map<string, Intl.NumberFormat>()

function formatter(min: number, max: number): Intl.NumberFormat {
  const key = `${min}-${max}`
  let f = cache.get(key)
  if (!f) {
    f = new Intl.NumberFormat("pt-BR", { minimumFractionDigits: min, maximumFractionDigits: max })
    cache.set(key, f)
  }
  return f
}

/** Formata número no padrão pt-BR (somente exibição). */
export function formatNumber(value: number, decimals = 2, minDecimals = decimals): string {
  if (!Number.isFinite(value)) return "—"
  return formatter(minDecimals, decimals).format(value)
}

export function formatCurrency(value: number, decimals = 2): string {
  if (!Number.isFinite(value)) return "—"
  return `R$ ${formatNumber(value, decimals)}`
}

export function formatPercent(value: number | null, decimals = 1): string {
  if (value === null || !Number.isFinite(value)) return "—"
  const sign = value > 0 ? "+" : ""
  return `${sign}${formatNumber(value, decimals)}%`
}

/** Notação científica legível: 1,234 × 10⁻⁴ */
export function formatScientific(value: number, decimals = 3): string {
  if (!Number.isFinite(value)) return "—"
  if (value === 0) return "0"
  const exp = Math.floor(Math.log10(Math.abs(value)))
  const mant = value / Math.pow(10, exp)
  const sup: Record<string, string> = {
    "-": "⁻", "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴", "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹",
  }
  const expStr = String(exp).split("").map((c) => sup[c] ?? c).join("")
  return `${formatNumber(mant, decimals)} × 10${expStr}`
}

/** Converte texto pt-BR ("1.234,56" ou "1234.56") em número; NaN se inválido. */
export function parseLocaleNumber(text: string): number {
  const trimmed = text.trim()
  if (trimmed === "") return Number.NaN
  let normalized = trimmed.replace(/\s/g, "")
  if (normalized.includes(",")) {
    normalized = normalized.replace(/\./g, "").replace(",", ".")
  }
  if (!/^[-+]?(\d+\.?\d*|\.\d+)(e[-+]?\d+)?$/i.test(normalized)) return Number.NaN
  return Number(normalized)
}

/** Representação editável (sem separador de milhar, vírgula decimal). */
export function toEditableString(value: number): string {
  if (!Number.isFinite(value)) return ""
  return String(value).replace(".", ",")
}
