import type { CavitationStatus, NpshResult, NpshTerms } from "@/types"
import { assertNonNegative, assertPositive } from "./units"

/**
 * Termos do NPSH disponível  [m]:
 * NPSHA = P0/(ρ·g) − Pv/(ρ·g) + (z0 − z_bomba) − h_sucção
 * (P0 e Pv em Pa absolutos)
 */
export function npshaTerms(params: {
  p0Pa: number
  pvPa: number
  z0: number
  zBomba: number
  perdaSuccao: number
  rho: number
  g: number
}): NpshTerms {
  assertPositive(params.rho, "Massa específica")
  assertPositive(params.g, "Aceleração da gravidade")
  assertNonNegative(params.p0Pa, "Pressão absoluta P0")
  assertNonNegative(params.pvPa, "Pressão de vapor")
  const rg = params.rho * params.g
  return {
    pressaoReservatorio: params.p0Pa / rg,
    pressaoVapor: -params.pvPa / rg,
    alturaGeometrica: params.z0 - params.zBomba,
    perdaSuccao: -params.perdaSuccao,
  }
}

/** NPSHA = Σ termos  [m] */
export function npshaFromTerms(t: NpshTerms): number {
  return t.pressaoReservatorio + t.pressaoVapor + t.alturaGeometrica + t.perdaSuccao
}

export function classifyCavitation(
  ratio: number,
  limiarSeguro = 1.3,
  limiarLimitrofe = 1.0,
): CavitationStatus {
  if (!Number.isFinite(ratio) || ratio < limiarLimitrofe) return "incompativel"
  if (ratio < limiarSeguro) return "limitrofe"
  return "seguro"
}

/** Margem = NPSHA − NPSHR [m]; razão = NPSHA / NPSHR [-] */
export function evaluateNpsh(
  terms: NpshTerms,
  npshr: number,
  limiarSeguro = 1.3,
  limiarLimitrofe = 1.0,
): NpshResult {
  assertPositive(npshr, "NPSHR")
  const npsha = npshaFromTerms(terms)
  const razao = npsha / npshr
  return {
    npsha,
    npshr,
    margem: npsha - npshr,
    razao,
    status: classifyCavitation(razao, limiarSeguro, limiarLimitrofe),
    termos: terms,
  }
}

export interface NpshContribution {
  chave: keyof NpshTerms
  rotulo: string
  valorM: number
  /** Participação no total de |termos| [%] */
  pesoPct: number
}

const TERM_LABEL: Record<keyof NpshTerms, string> = {
  pressaoReservatorio: "Pressão no reservatório (P0/ρg)",
  pressaoVapor: "Pressão de vapor (−Pv/ρg)",
  alturaGeometrica: "Altura geométrica de sucção (z0 − z_bomba)",
  perdaSuccao: "Perda na sucção (−h_s)",
}

/** Contribuição de cada termo do NPSHA [m], ordenada por magnitude. */
export function npshContributions(t: NpshTerms): NpshContribution[] {
  const keys = Object.keys(TERM_LABEL) as Array<keyof NpshTerms>
  const total = keys.reduce((acc, k) => acc + Math.abs(t[k]), 0)
  return keys
    .map((k) => ({ chave: k, rotulo: TERM_LABEL[k], valorM: t[k], pesoPct: total > 0 ? (Math.abs(t[k]) / total) * 100 : 0 }))
    .sort((a, b) => Math.abs(b.valorM) - Math.abs(a.valorM))
}

export const CAVITATION_LABEL: Record<CavitationStatus, string> = {
  seguro: "Tecnicamente seguro",
  limitrofe: "Limítrofe",
  incompativel: "Incompatível com operação contínua",
}
