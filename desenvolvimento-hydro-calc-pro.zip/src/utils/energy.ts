import type { HeadComposition } from "@/types"
import { assertNonNegative, assertPositive, normalizeEfficiency } from "./units"

/**
 * Altura manométrica (Bernoulli entre superfícies, V desprezível):
 * H = (P2 − P0)/(ρ·g) + (z2 − z0) + h_sucção + h_recalque  [m], pressões em Pa
 */
export function totalDynamicHead(params: {
  p0Pa: number
  p2Pa: number
  z0: number
  z2: number
  rho: number
  g: number
  perdaSuccao: number
  perdaRecalque: number
}): HeadComposition {
  assertPositive(params.rho, "Massa específica")
  assertPositive(params.g, "Aceleração da gravidade")
  const pressao = (params.p2Pa - params.p0Pa) / (params.rho * params.g)
  const desnivel = params.z2 - params.z0
  const total = pressao + desnivel + params.perdaSuccao + params.perdaRecalque
  return { pressao, desnivel, perdaSuccao: params.perdaSuccao, perdaRecalque: params.perdaRecalque, total }
}

/** Potência hidráulica: Ph = ρ·g·Q·H  [W] */
export function hydraulicPower(rho: number, g: number, flowM3s: number, headM: number): number {
  assertPositive(rho, "Massa específica")
  assertPositive(g, "Aceleração da gravidade")
  assertNonNegative(flowM3s, "Vazão")
  return rho * g * flowM3s * headM
}

/** Potência no eixo: Peixo = Ph / η_bomba  [W] */
export function shaftPower(hydraulicW: number, etaPump: number): number {
  return hydraulicW / normalizeEfficiency(etaPump, "Rendimento da bomba")
}

/** Potência elétrica: Pel = Peixo / η_motor  [W] */
export function electricPower(shaftW: number, etaMotor: number): number {
  return shaftW / normalizeEfficiency(etaMotor, "Rendimento do motor")
}

/** Energia mensal: E = Pel[kW] · h/dia · dias/mês  [kWh/mês] */
export function monthlyEnergyKWh(electricKW: number, hoursPerDay: number, daysPerMonth: number): number {
  assertNonNegative(hoursPerDay, "Horas por dia")
  assertNonNegative(daysPerMonth, "Dias por mês")
  if (hoursPerDay > 24) throw new RangeError("Horas por dia não pode exceder 24.")
  if (daysPerMonth > 31) throw new RangeError("Dias por mês não pode exceder 31.")
  return electricKW * hoursPerDay * daysPerMonth
}

/** Custo mensal = E · tarifa  [R$/mês] */
export function monthlyCost(energyKWh: number, tariffPerKWh: number): number {
  assertNonNegative(tariffPerKWh, "Tarifa")
  return energyKWh * tariffPerKWh
}
