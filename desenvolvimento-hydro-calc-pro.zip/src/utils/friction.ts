import type { FrictionMethod, FrictionResult } from "@/types"
import { assertNonNegative, assertPositive } from "./units"

export const COLEBROOK_TOLERANCE = 1e-10
export const COLEBROOK_MAX_ITERATIONS = 100

/** Laminar (Hagen–Poiseuille): f = 64 / Re  [-] */
export function laminarFriction(re: number): number {
  assertPositive(re, "Número de Reynolds")
  return 64 / re
}

/** Swamee–Jain: f = 0,25 / [log10(ε/(3,7D) + 5,74/Re^0,9)]²  [-] */
export function swameeJainFriction(re: number, relRoughness: number): number {
  assertPositive(re, "Número de Reynolds")
  assertNonNegative(relRoughness, "Rugosidade relativa")
  const term = Math.log10(relRoughness / 3.7 + 5.74 / Math.pow(re, 0.9))
  return 0.25 / (term * term)
}

/**
 * Colebrook–White (iterativo): 1/√f = −2·log10(ε/(3,7D) + 2,51/(Re·√f))  [-]
 * Estimativa inicial por Swamee–Jain; critério |Δf| < 1e-10.
 */
export function colebrookFriction(
  re: number,
  relRoughness: number,
  tolerance = COLEBROOK_TOLERANCE,
  maxIterations = COLEBROOK_MAX_ITERATIONS,
): FrictionResult {
  assertPositive(re, "Número de Reynolds")
  assertNonNegative(relRoughness, "Rugosidade relativa")

  let f = swameeJainFriction(re, relRoughness)
  for (let i = 1; i <= maxIterations; i++) {
    const invSqrt = -2 * Math.log10(relRoughness / 3.7 + 2.51 / (re * Math.sqrt(f)))
    const next = 1 / (invSqrt * invSqrt)
    if (Math.abs(next - f) < tolerance) {
      return { f: next, iteracoes: i, convergiu: true, metodo: "colebrook" }
    }
    f = next
  }
  return { f, iteracoes: maxIterations, convergiu: false, metodo: "colebrook" }
}

/**
 * Fator de atrito de Darcy conforme regime.
 * Re < reLaminar → 64/Re. Demais casos → correlação turbulenta selecionada
 * (na faixa de transição o resultado é incerto e deve ser sinalizado).
 */
export function darcyFrictionFactor(
  re: number,
  relRoughness: number,
  method: FrictionMethod,
  reLaminar = 2300,
): FrictionResult {
  assertPositive(re, "Número de Reynolds")
  if (re < reLaminar) {
    return { f: laminarFriction(re), iteracoes: 0, convergiu: true, metodo: "laminar" }
  }
  if (method === "swamee-jain") {
    return { f: swameeJainFriction(re, relRoughness), iteracoes: 0, convergiu: true, metodo: "swamee-jain" }
  }
  return colebrookFriction(re, relRoughness)
}
