import type { Singularity } from "@/types"
import { assertNonNegative, assertPositive } from "./units"

/** K total de uma singularidade = quantidade · K unitário  [-] */
export function singularityTotalK(s: Singularity): number {
  assertNonNegative(s.quantidade, `Quantidade (${s.nome})`)
  assertNonNegative(s.kUnitario, `K unitário (${s.nome})`)
  return s.quantidade * s.kUnitario
}

/** ΣK = Σ (quantidade · K)  [-] */
export function sumK(singularities: Singularity[]): number {
  return singularities.reduce((acc, s) => acc + singularityTotalK(s), 0)
}

/** Darcy–Weisbach: hf = f·(L/D)·V²/(2g)  [m] */
export function distributedLoss(f: number, lengthM: number, diameterM: number, velocity: number, g: number): number {
  assertNonNegative(f, "Fator de atrito")
  assertNonNegative(lengthM, "Comprimento")
  assertPositive(diameterM, "Diâmetro")
  assertPositive(g, "Aceleração da gravidade")
  return f * (lengthM / diameterM) * ((velocity * velocity) / (2 * g))
}

/** Perda localizada: hl = ΣK·V²/(2g)  [m] */
export function localLoss(totalK: number, velocity: number, g: number): number {
  assertNonNegative(totalK, "ΣK")
  assertPositive(g, "Aceleração da gravidade")
  return totalK * ((velocity * velocity) / (2 * g))
}
