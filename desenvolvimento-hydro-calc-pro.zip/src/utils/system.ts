import type {
  FrictionMethod,
  PipeSection,
  SectionResult,
  Settings,
  SystemAlert,
  SystemInput,
  SystemResult,
} from "@/types"
import { darcyFrictionFactor } from "./friction"
import { classifyRegime, flowVelocity, pipeArea, relativeRoughness, reynoldsNumber, velocityHead } from "./hydraulics"
import { distributedLoss, localLoss, sumK } from "./losses"
import { electricPower, hydraulicPower, monthlyCost, monthlyEnergyKWh, shaftPower, totalDynamicHead } from "./energy"
import { CAVITATION_LABEL, evaluateNpsh, npshaTerms } from "./npsh"
import { assertNonNegative, assertPositive, kPaToPa, m3hToM3s, mmToM, normalizeEfficiency, wToKW } from "./units"

export type ThresholdSettings = Pick<
  Settings,
  "limiarSeguro" | "limiarLimitrofe" | "vMaxSuccao" | "vMaxRecalque" | "reLaminar" | "reTurbulento" | "rugRelMax"
>

export const DEFAULT_THRESHOLDS: ThresholdSettings = {
  limiarSeguro: 1.3,
  limiarLimitrofe: 1.0,
  vMaxSuccao: 2.0,
  vMaxRecalque: 3.0,
  reLaminar: 2300,
  reTurbulento: 4000,
  rugRelMax: 0.05,
}

/** Calcula velocidade, Re, f e perdas de um trecho de tubulação. Unidades SI. */
export function computeSection(
  section: PipeSection,
  flowM3s: number,
  rho: number,
  mu: number,
  g: number,
  method: FrictionMethod,
  thresholds: Pick<ThresholdSettings, "reLaminar" | "reTurbulento"> = DEFAULT_THRESHOLDS,
): SectionResult {
  assertPositive(section.diametroMm, "Diâmetro")
  assertPositive(section.comprimentoM, "Comprimento")
  assertNonNegative(section.materialOuEpsilonMm, "Rugosidade")

  const diametroM = mmToM(section.diametroMm)
  const areaM2 = pipeArea(diametroM)
  const velocidade = flowVelocity(flowM3s, diametroM)
  const cargaCinetica = velocityHead(velocidade, g)
  const rugosidadeRelativa = relativeRoughness(section.materialOuEpsilonMm, section.diametroMm)
  const somaK = sumK(section.singularidades)

  if (flowM3s === 0) {
    return {
      diametroM,
      areaM2,
      velocidade: 0,
      cargaCinetica: 0,
      reynolds: 0,
      regime: "estatico",
      rugosidadeRelativa,
      atrito: { f: 0, iteracoes: 0, convergiu: true, metodo: method },
      somaK,
      perdaDistribuida: 0,
      perdaLocalizada: 0,
      perdaTotal: 0,
    }
  }

  const reynolds = reynoldsNumber(rho, velocidade, diametroM, mu)
  const regime = classifyRegime(reynolds, thresholds.reLaminar, thresholds.reTurbulento)
  const atrito = darcyFrictionFactor(reynolds, rugosidadeRelativa, method, thresholds.reLaminar)
  const perdaDistribuida = distributedLoss(atrito.f, section.comprimentoM, diametroM, velocidade, g)
  const perdaLocalizada = localLoss(somaK, velocidade, g)

  return {
    diametroM,
    areaM2,
    velocidade,
    cargaCinetica,
    reynolds,
    regime,
    rugosidadeRelativa,
    atrito,
    somaK,
    perdaDistribuida,
    perdaLocalizada,
    perdaTotal: perdaDistribuida + perdaLocalizada,
  }
}

const ALERT_ORDER = { critico: 0, atencao: 1, ok: 2 } as const

export function sortAlerts(alerts: SystemAlert[]): SystemAlert[] {
  return [...alerts].sort((a, b) => ALERT_ORDER[a.nivel] - ALERT_ORDER[b.nivel])
}

function fmt(v: number, d = 2): string {
  return v.toLocaleString("pt-BR", { minimumFractionDigits: d, maximumFractionDigits: d })
}

function sectionAlerts(
  label: string,
  r: SectionResult,
  vMax: number,
  method: FrictionMethod,
  t: ThresholdSettings,
): SystemAlert[] {
  const out: SystemAlert[] = []
  if (r.regime === "transicao") {
    out.push({
      nivel: "atencao",
      grandeza: `Re ${label}`,
      mensagem: `Regime de transição na ${label} (Re = ${fmt(r.reynolds, 0)}, entre ${fmt(t.reLaminar, 0)} e ${fmt(t.reTurbulento, 0)}): fator de atrito incerto.`,
    })
  }
  if (r.regime === "laminar") {
    out.push({
      nivel: "ok",
      grandeza: `Re ${label}`,
      mensagem: `Escoamento laminar na ${label} (Re = ${fmt(r.reynolds, 0)}); f = 64/Re aplicado.`,
    })
  }
  if (r.velocidade > vMax) {
    out.push({
      nivel: "atencao",
      grandeza: `V ${label}`,
      mensagem: `Velocidade na ${label} de ${fmt(r.velocidade)} m/s acima do limite recomendado de ${fmt(vMax)} m/s.`,
    })
  }
  if (r.rugosidadeRelativa > t.rugRelMax) {
    out.push({
      nivel: "atencao",
      grandeza: `ε/D ${label}`,
      mensagem: `Rugosidade relativa da ${label} (${fmt(r.rugosidadeRelativa, 4)}) fora da faixa de validade (≤ ${fmt(t.rugRelMax, 3)}).`,
    })
  }
  if (method === "swamee-jain" && r.regime === "turbulento") {
    if (r.rugosidadeRelativa > 0 && (r.rugosidadeRelativa < 1e-6 || r.rugosidadeRelativa > 1e-2)) {
      out.push({
        nivel: "atencao",
        grandeza: `ε/D ${label}`,
        mensagem: `Swamee-Jain válido para 10⁻⁶ ≤ ε/D ≤ 10⁻² (${label}: ${fmt(r.rugosidadeRelativa, 6)}).`,
      })
    }
    if (r.reynolds < 5000 || r.reynolds > 1e8) {
      out.push({
        nivel: "atencao",
        grandeza: `Re ${label}`,
        mensagem: `Swamee-Jain válido para 5.000 ≤ Re ≤ 10⁸ (${label}: ${fmt(r.reynolds, 0)}).`,
      })
    }
  }
  if (!r.atrito.convergiu) {
    out.push({
      nivel: "critico",
      grandeza: `f ${label}`,
      mensagem: `Colebrook-White não convergiu na ${label} após ${r.atrito.iteracoes} iterações.`,
    })
  }
  return out
}

/**
 * Cálculo completo do sistema de bombeamento (SI interno, sem arredondamentos).
 * Lança EngineeringInputError para entradas inválidas.
 */
export function computeSystem(input: SystemInput, thresholds: ThresholdSettings = DEFAULT_THRESHOLDS): SystemResult {
  const { fluido, g } = input
  assertPositive(g, "Aceleração da gravidade")
  assertPositive(fluido.rho, "Massa específica")
  assertPositive(fluido.mu, "Viscosidade dinâmica")
  assertNonNegative(fluido.pv, "Pressão de vapor")
  assertNonNegative(input.vazaoM3h, "Vazão")
  assertNonNegative(input.p0KPaAbs, "P0 (abs)")
  assertNonNegative(input.p2KPaAbs, "P2 (abs)")
  const etaBomba = normalizeEfficiency(input.etaBomba, "Rendimento da bomba")
  const etaMotor = normalizeEfficiency(input.etaMotor, "Rendimento do motor")

  const vazaoM3s = m3hToM3s(input.vazaoM3h)
  const p0Pa = kPaToPa(input.p0KPaAbs)
  const p2Pa = kPaToPa(input.p2KPaAbs)
  const pvPa = kPaToPa(fluido.pv)

  const succao = computeSection(input.succao, vazaoM3s, fluido.rho, fluido.mu, g, input.metodoAtrito, thresholds)
  const recalque = computeSection(input.recalque, vazaoM3s, fluido.rho, fluido.mu, g, input.metodoAtrito, thresholds)

  const altura = totalDynamicHead({
    p0Pa,
    p2Pa,
    z0: input.z0,
    z2: input.z2,
    rho: fluido.rho,
    g,
    perdaSuccao: succao.perdaTotal,
    perdaRecalque: recalque.perdaTotal,
  })

  const hidraulicaW = hydraulicPower(fluido.rho, g, vazaoM3s, altura.total)
  const eixoW = shaftPower(hidraulicaW, etaBomba)
  const eletricaW = electricPower(eixoW, etaMotor)
  const energiaMensalKWh = monthlyEnergyKWh(wToKW(eletricaW), input.horasDia, input.diasMes)
  const custoMensal = monthlyCost(energiaMensalKWh, input.tarifaKWh)

  const termos = npshaTerms({
    p0Pa,
    pvPa,
    z0: input.z0,
    zBomba: input.zBomba,
    perdaSuccao: succao.perdaTotal,
    rho: fluido.rho,
    g,
  })
  const npsh = evaluateNpsh(termos, input.npshr, thresholds.limiarSeguro, thresholds.limiarLimitrofe)

  const alerts: SystemAlert[] = [
    ...sectionAlerts("sucção", succao, thresholds.vMaxSuccao, input.metodoAtrito, thresholds),
    ...sectionAlerts("recalque", recalque, thresholds.vMaxRecalque, input.metodoAtrito, thresholds),
  ]

  if (npsh.npsha <= 0) {
    alerts.push({
      nivel: "critico",
      grandeza: "NPSHA",
      mensagem: `NPSHA de ${fmt(npsh.npsha)} m é nulo ou negativo: o líquido vaporiza antes de chegar à bomba.`,
    })
  }
  const statusNivel = npsh.status === "seguro" ? "ok" : npsh.status === "limitrofe" ? "atencao" : "critico"
  alerts.push({
    nivel: statusNivel,
    grandeza: "NPSHA/NPSHR",
    mensagem: `${CAVITATION_LABEL[npsh.status]}: razão NPSHA/NPSHR = ${fmt(npsh.razao)} (limiar seguro ${fmt(thresholds.limiarSeguro)}), margem de ${fmt(npsh.margem)} m.`,
  })
  if (altura.total <= 0) {
    alerts.push({
      nivel: "atencao",
      grandeza: "H",
      mensagem: "Altura manométrica nula ou negativa: o escoamento ocorre por gravidade/pressão, sem necessidade de bomba.",
    })
  }
  if (input.zBomba > input.z0) {
    alerts.push({
      nivel: "ok",
      grandeza: "Sucção",
      mensagem: `Bomba em sucção positiva de ${fmt(input.zBomba - input.z0)} m acima do nível (altura geométrica negativa no NPSHA).`,
    })
  }

  return {
    vazaoM3s,
    p0Pa,
    p2Pa,
    pvPa,
    succao,
    recalque,
    altura,
    potencia: { hidraulicaW, eixoW, eletricaW, energiaMensalKWh, custoMensal },
    npsh,
    alerts: sortAlerts(alerts),
  }
}
