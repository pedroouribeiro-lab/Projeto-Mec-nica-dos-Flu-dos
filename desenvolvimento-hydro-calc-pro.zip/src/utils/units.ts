export class EngineeringInputError extends Error {
  constructor(
    message: string,
    public readonly grandeza: string,
  ) {
    super(message)
    this.name = "EngineeringInputError"
  }
}

export function assertFinite(value: number, grandeza: string): void {
  if (!Number.isFinite(value)) {
    throw new EngineeringInputError(`${grandeza} deve ser um número finito.`, grandeza)
  }
}

export function assertPositive(value: number, grandeza: string): void {
  assertFinite(value, grandeza)
  if (value <= 0) {
    throw new EngineeringInputError(`${grandeza} deve ser maior que zero.`, grandeza)
  }
}

export function assertNonNegative(value: number, grandeza: string): void {
  assertFinite(value, grandeza)
  if (value < 0) {
    throw new EngineeringInputError(`${grandeza} não pode ser negativo.`, grandeza)
  }
}

/** Q [m³/s] = Q [m³/h] / 3600 */
export function m3hToM3s(q: number): number {
  return q / 3600
}

export function m3sToM3h(q: number): number {
  return q * 3600
}

/** L/s = m³/h / 3,6 */
export function m3hToLs(q: number): number {
  return q / 3.6
}

/** P [Pa] = P [kPa] · 1000 */
export function kPaToPa(p: number): number {
  return p * 1000
}

/** D [m] = D [mm] / 1000 */
export function mmToM(d: number): number {
  return d / 1000
}

export function wToKW(p: number): number {
  return p / 1000
}

/** 1 cv = 735,49875 W */
export function wToCv(p: number): number {
  return p / 735.49875
}

/** Carga de pressão [m] a partir de kPa: h = P / (ρ·g) */
export function kPaToHeadM(pKPa: number, rho: number, g: number): number {
  return kPaToPa(pKPa) / (rho * g)
}

/**
 * Normaliza rendimento informado como fração (0–1] ou porcentagem (1–100].
 * Valores maiores que 1 são interpretados como porcentagem.
 */
export function normalizeEfficiency(value: number, grandeza = "Rendimento"): number {
  assertFinite(value, grandeza)
  const eta = value > 1 ? value / 100 : value
  if (eta <= 0 || eta > 1) {
    throw new EngineeringInputError(
      `${grandeza} deve estar entre 0 e 1 (ou entre 0% e 100%).`,
      grandeza,
    )
  }
  return eta
}

export function isValidEfficiency(value: number): boolean {
  if (!Number.isFinite(value)) return false
  const eta = value > 1 ? value / 100 : value
  return eta > 0 && eta <= 1
}
