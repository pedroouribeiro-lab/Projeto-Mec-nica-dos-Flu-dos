export interface XY {
  x: number
  y: number
}

/** Interpolação linear y(x) em série ordenada por x. Retorna null fora do domínio. */
export function linearInterpolate(points: XY[], x: number): number | null {
  if (points.length < 2) return null
  const sorted = [...points].sort((a, b) => a.x - b.x)
  if (x < sorted[0].x || x > sorted[sorted.length - 1].x) return null
  for (let i = 0; i < sorted.length - 1; i++) {
    const a = sorted[i]
    const b = sorted[i + 1]
    if (x >= a.x && x <= b.x) {
      if (b.x === a.x) return a.y
      return a.y + ((b.y - a.y) * (x - a.x)) / (b.x - a.x)
    }
  }
  return null
}

/**
 * Primeiro cruzamento de d(x) = y1(x) − y2(x) por interpolação linear
 * entre amostras consecutivas com troca de sinal.
 */
export function findCrossing(xs: number[], y1: number[], y2: number[]): number | null {
  const n = Math.min(xs.length, y1.length, y2.length)
  for (let i = 0; i < n - 1; i++) {
    const d0 = y1[i] - y2[i]
    const d1 = y1[i + 1] - y2[i + 1]
    if (d0 === 0) return xs[i]
    if (d0 * d1 < 0) {
      return xs[i] + ((xs[i + 1] - xs[i]) * d0) / (d0 - d1)
    }
  }
  if (n > 0 && y1[n - 1] - y2[n - 1] === 0) return xs[n - 1]
  return null
}

export function linspace(start: number, end: number, count: number): number[] {
  if (count < 2) return [start]
  const step = (end - start) / (count - 1)
  return Array.from({ length: count }, (_, i) => start + step * i)
}

/** Variação percentual (b − a)/|a|·100; null quando a = 0 */
export function percentChange(a: number, b: number): number | null {
  if (a === 0) return b === 0 ? 0 : null
  return ((b - a) / Math.abs(a)) * 100
}
