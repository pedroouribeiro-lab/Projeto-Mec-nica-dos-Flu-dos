import type { FlowRegime } from "@/types"
import { assertNonNegative, assertPositive } from "./units"

/** A = π·D²/4  [m²], D em m */
export function pipeArea(diameterM: number): number {
  assertPositive(diameterM, "Diâmetro")
  return (Math.PI * diameterM * diameterM) / 4
}

/** V = Q / A  [m/s], Q em m³/s, D em m */
export function flowVelocity(flowM3s: number, diameterM: number): number {
  assertNonNegative(flowM3s, "Vazão")
  return flowM3s / pipeArea(diameterM)
}

/** Re = ρ·V·D / μ  [-] */
export function reynoldsNumber(rho: number, velocity: number, diameterM: number, mu: number): number {
  assertPositive(rho, "Massa específica")
  assertPositive(mu, "Viscosidade dinâmica")
  assertPositive(diameterM, "Diâmetro")
  assertNonNegative(velocity, "Velocidade")
  return (rho * velocity * diameterM) / mu
}

/** ε/D  [-], ambos na mesma unidade */
export function relativeRoughness(epsilonMm: number, diameterMm: number): number {
  assertNonNegative(epsilonMm, "Rugosidade")
  assertPositive(diameterMm, "Diâmetro")
  return epsilonMm / diameterMm
}

/** Carga cinética V²/(2g)  [m] */
export function velocityHead(velocity: number, g: number): number {
  assertPositive(g, "Aceleração da gravidade")
  return (velocity * velocity) / (2 * g)
}

export function classifyRegime(re: number, reLaminar = 2300, reTurbulento = 4000): FlowRegime {
  if (re === 0) return "estatico"
  if (re < reLaminar) return "laminar"
  if (re <= reTurbulento) return "transicao"
  return "turbulento"
}
