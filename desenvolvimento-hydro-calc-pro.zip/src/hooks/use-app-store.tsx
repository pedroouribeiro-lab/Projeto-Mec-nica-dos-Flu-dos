"use client"

import * as React from "react"
import type {
  AppState,
  Fluid,
  Material,
  Premise,
  PumpCurvePoint,
  Reference,
  Scenario,
  Settings,
  SystemInput,
  UnitSystem,
} from "@/types"
import { createDefaultState, createId, loadState, saveState } from "@/services/storage"

type Listener = () => void

let currentState: AppState | null = null
const listeners = new Set<Listener>()
const serverState = createDefaultState()

function getState(): AppState {
  if (currentState === null) currentState = loadState()
  return currentState
}

function setState(updater: (s: AppState) => AppState) {
  currentState = updater(getState())
  saveState(currentState)
  listeners.forEach((l) => l())
}

function subscribe(listener: Listener) {
  listeners.add(listener)
  return () => listeners.delete(listener)
}

const noopSubscribe = () => () => {}

export function useHydrated(): boolean {
  return React.useSyncExternalStore(
    noopSubscribe,
    () => true,
    () => false,
  )
}

function touch(s: Scenario): Scenario {
  return { ...s, atualizadoEm: new Date().toISOString() }
}

const actions = {
  setProjectName(nome: string) {
    setState((s) => ({ ...s, nomeProjeto: nome }))
  },
  setUnits(unidades: UnitSystem) {
    setState((s) => ({ ...s, unidades }))
  },
  setActiveScenario(id: string) {
    setState((s) => (s.cenarios.some((c) => c.id === id) ? { ...s, cenarioAtivoId: id } : s))
  },
  updateScenarioInput(id: string, input: SystemInput) {
    setState((s) => ({ ...s, cenarios: s.cenarios.map((c) => (c.id === id ? touch({ ...c, input }) : c)) }))
  },
  updateScenarioMeta(id: string, meta: { nome?: string; descricao?: string }) {
    setState((s) => ({ ...s, cenarios: s.cenarios.map((c) => (c.id === id ? touch({ ...c, ...meta }) : c)) }))
  },
  updatePumpCurve(id: string, curvaBomba: PumpCurvePoint[]) {
    setState((s) => ({ ...s, cenarios: s.cenarios.map((c) => (c.id === id ? touch({ ...c, curvaBomba }) : c)) }))
  },
  addScenario(scenario: Omit<Scenario, "id" | "criadoEm" | "atualizadoEm">, activate = true): string {
    const agora = new Date().toISOString()
    const novo: Scenario = { ...scenario, id: createId("cen"), criadoEm: agora, atualizadoEm: agora }
    setState((s) => ({ ...s, cenarios: [...s.cenarios, novo], cenarioAtivoId: activate ? novo.id : s.cenarioAtivoId }))
    return novo.id
  },
  duplicateScenario(id: string, overrides?: { nome?: string; descricao?: string; input?: SystemInput }): string | null {
    const origem = getState().cenarios.find((c) => c.id === id)
    if (!origem) return null
    return actions.addScenario({
      nome: overrides?.nome ?? `${origem.nome} (cópia)`,
      descricao: overrides?.descricao ?? origem.descricao,
      input: structuredClone(overrides?.input ?? origem.input),
      curvaBomba: structuredClone(origem.curvaBomba),
    })
  },
  deleteScenario(id: string) {
    setState((s) => {
      if (s.cenarios.length <= 1) return s
      const cenarios = s.cenarios.filter((c) => c.id !== id)
      return { ...s, cenarios, cenarioAtivoId: s.cenarioAtivoId === id ? cenarios[0].id : s.cenarioAtivoId }
    })
  },
  upsertFluid(fluid: Fluid) {
    setState((s) => {
      const withId = { ...fluid, id: fluid.id ?? createId("flu") }
      const exists = s.fluidos.some((f) => f.id === withId.id)
      return { ...s, fluidos: exists ? s.fluidos.map((f) => (f.id === withId.id ? withId : f)) : [...s.fluidos, withId] }
    })
  },
  deleteFluid(id: string) {
    setState((s) => ({ ...s, fluidos: s.fluidos.filter((f) => f.id !== id) }))
  },
  upsertMaterial(material: Material) {
    setState((s) => {
      const withId = { ...material, id: material.id ?? createId("mat") }
      const exists = s.materiais.some((m) => m.id === withId.id)
      return { ...s, materiais: exists ? s.materiais.map((m) => (m.id === withId.id ? withId : m)) : [...s.materiais, withId] }
    })
  },
  deleteMaterial(id: string) {
    setState((s) => ({ ...s, materiais: s.materiais.filter((m) => m.id !== id) }))
  },
  updateSettings(configuracoes: Settings) {
    setState((s) => ({ ...s, configuracoes }))
  },
  setPremises(premissas: Premise[]) {
    setState((s) => ({ ...s, premissas }))
  },
  setReferences(referencias: Reference[]) {
    setState((s) => ({ ...s, referencias }))
  },
  resetAll() {
    setState(() => createDefaultState())
  },
}

export type AppActions = typeof actions

export function useAppState(): AppState {
  return React.useSyncExternalStore(subscribe, getState, () => serverState)
}

export function useAppActions(): AppActions {
  return actions
}

export function useActiveScenario(): Scenario {
  const state = useAppState()
  return state.cenarios.find((c) => c.id === state.cenarioAtivoId) ?? state.cenarios[0]
}
