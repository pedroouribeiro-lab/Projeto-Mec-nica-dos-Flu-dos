"use client"

import * as React from "react"
import type { Scenario, Settings } from "@/types"
import { runCalculation, type CalculationOutcome } from "@/services/calculation"
import { resolveInput } from "@/services/storage"
import { useActiveScenario, useAppState } from "./use-app-store"

export function useScenarioCalculation(scenario: Scenario | undefined, settings: Settings): CalculationOutcome | null {
  return React.useMemo(
    () => (scenario ? runCalculation(resolveInput(scenario.input, settings), settings) : null),
    [scenario, settings],
  )
}

export function useActiveCalculation() {
  const state = useAppState()
  const scenario = useActiveScenario()
  const outcome = useScenarioCalculation(scenario, state.configuracoes)
  const input = React.useMemo(() => resolveInput(scenario.input, state.configuracoes), [scenario, state.configuracoes])
  return { state, scenario, input, outcome }
}
