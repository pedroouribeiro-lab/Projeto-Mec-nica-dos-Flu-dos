"use client"

import { formatNumber } from "@/utils/format"
import { m3hToLs, wToCv, wToKW } from "@/utils/units"
import { useAppState } from "./use-app-store"

export interface DisplayValue {
  valor: string
  unidade: string
}

export function useUnits() {
  const { unidades } = useAppState()
  const tecnico = unidades === "tecnico"
  return {
    unidades,
    power(w: number, decimals = 2): DisplayValue {
      return tecnico ? { valor: formatNumber(wToCv(w), decimals), unidade: "cv" } : { valor: formatNumber(wToKW(w), decimals), unidade: "kW" }
    },
    flow(m3h: number, decimals = 2): DisplayValue {
      return tecnico ? { valor: formatNumber(m3hToLs(m3h), decimals), unidade: "L/s" } : { valor: formatNumber(m3h, decimals), unidade: "m³/h" }
    },
  }
}
