import { describe, expect, it } from "vitest"
import { criarCasoExemplo } from "@/data/example-case"
import { runCalculation } from "@/services/calculation"
import { CONFIGURACOES_PADRAO } from "@/data/example-case"
import { colebrookFriction, darcyFrictionFactor, laminarFriction, swameeJainFriction } from "@/utils/friction"
import { classifyRegime, flowVelocity } from "@/utils/hydraulics"
import { classifyCavitation, evaluateNpsh, npshContributions } from "@/utils/npsh"
import { computeSystem } from "@/utils/system"
import { EngineeringInputError, isValidEfficiency, normalizeEfficiency } from "@/utils/units"
import { findCrossing, linearInterpolate } from "@/utils/interpolation"
import { parseLocaleNumber } from "@/utils/format"

describe("Regime laminar", () => {
  it("f = 64/Re", () => {
    expect(laminarFriction(1000)).toBeCloseTo(0.064, 12)
    expect(darcyFrictionFactor(1500, 0.001, "colebrook").metodo).toBe("laminar")
  })
  it("fluido muito viscoso gera regime laminar", () => {
    const input = criarCasoExemplo()
    input.fluido = { ...input.fluido, mu: 1.5 }
    const r = computeSystem(input)
    expect(r.succao.regime).toBe("laminar")
    expect(r.succao.atrito.f).toBeCloseTo(64 / r.succao.reynolds, 12)
  })
})

describe("Regime de transição", () => {
  it("classifica 2300–4000 como transição", () => {
    expect(classifyRegime(2300)).toBe("transicao")
    expect(classifyRegime(3000)).toBe("transicao")
    expect(classifyRegime(4000)).toBe("transicao")
    expect(classifyRegime(4001)).toBe("turbulento")
  })
  it("gera alerta de atenção", () => {
    const input = criarCasoExemplo()
    input.vazaoM3h = 30
    input.fluido = { ...input.fluido, mu: 0.003 * (45757 / 3000) }
    const r = computeSystem(input)
    expect(r.succao.regime).toBe("transicao")
    expect(r.alerts.some((a) => a.nivel === "atencao" && a.mensagem.includes("transição"))).toBe(true)
  })
})

describe("Fator de atrito turbulento", () => {
  it("Colebrook converge e é próximo de Swamee-Jain", () => {
    const c = colebrookFriction(1e5, 1e-4)
    const s = swameeJainFriction(1e5, 1e-4)
    expect(c.convergiu).toBe(true)
    expect(Math.abs(c.f - s) / c.f).toBeLessThan(0.02)
  })
  it("Colebrook satisfaz a equação implícita", () => {
    const re = 56316
    const e = 0.045 / 65
    const { f } = colebrookFriction(re, e)
    const rhs = -2 * Math.log10(e / 3.7 + 2.51 / (re * Math.sqrt(f)))
    expect(1 / Math.sqrt(f)).toBeCloseTo(rhs, 8)
  })
})

describe("Rendimento inválido", () => {
  it("aceita fração e porcentagem", () => {
    expect(normalizeEfficiency(0.68)).toBeCloseTo(0.68, 12)
    expect(normalizeEfficiency(68)).toBeCloseTo(0.68, 12)
  })
  it("rejeita zero, negativo e acima de 100%", () => {
    expect(() => normalizeEfficiency(0)).toThrow(EngineeringInputError)
    expect(() => normalizeEfficiency(-0.5)).toThrow(EngineeringInputError)
    expect(() => normalizeEfficiency(120)).toThrow(EngineeringInputError)
    expect(isValidEfficiency(Number.NaN)).toBe(false)
  })
  it("cálculo retorna erro tratado", () => {
    const input = { ...criarCasoExemplo(), etaBomba: 0 }
    const out = runCalculation(input, CONFIGURACOES_PADRAO)
    expect(out.ok).toBe(false)
  })
})

describe("Diâmetro zero", () => {
  it("velocidade lança erro", () => {
    expect(() => flowVelocity(0.01, 0)).toThrow(EngineeringInputError)
  })
  it("sistema lança erro com diâmetro zero", () => {
    const input = criarCasoExemplo()
    input.succao = { ...input.succao, diametroMm: 0 }
    expect(() => computeSystem(input)).toThrow(EngineeringInputError)
    expect(runCalculation(input, CONFIGURACOES_PADRAO).ok).toBe(false)
  })
})

describe("NPSHA negativo", () => {
  it("bomba muito acima do nível gera NPSHA negativo e alerta crítico", () => {
    const input = { ...criarCasoExemplo(), zBomba: 12 }
    const r = computeSystem(input)
    expect(r.npsh.npsha).toBeLessThan(0)
    expect(r.npsh.status).toBe("incompativel")
    expect(r.alerts[0].nivel).toBe("critico")
    expect(r.alerts.some((a) => a.grandeza === "NPSHA")).toBe(true)
  })
  it("classificação por limiar", () => {
    expect(classifyCavitation(1.82)).toBe("seguro")
    expect(classifyCavitation(1.3)).toBe("seguro")
    expect(classifyCavitation(1.15)).toBe("limitrofe")
    expect(classifyCavitation(0.9)).toBe("incompativel")
  })
  it("contribuições somam o NPSHA", () => {
    const r = computeSystem(criarCasoExemplo())
    const soma = npshContributions(r.npsh.termos).reduce((a, c) => a + c.valorM, 0)
    expect(soma).toBeCloseTo(r.npsh.npsha, 10)
    expect(() => evaluateNpsh(r.npsh.termos, 0)).toThrow(EngineeringInputError)
  })
})

describe("Vazão nula", () => {
  it("sem perdas e sem divisão por zero", () => {
    const r = computeSystem({ ...criarCasoExemplo(), vazaoM3h: 0 })
    expect(r.succao.perdaTotal).toBe(0)
    expect(r.altura.total).toBeCloseTo(17.2, 10)
    expect(r.potencia.eletricaW).toBe(0)
  })
})

describe("Interpolação e utilidades", () => {
  it("interpola linearmente e detecta cruzamento", () => {
    expect(linearInterpolate([{ x: 0, y: 0 }, { x: 10, y: 20 }], 5)).toBe(10)
    expect(linearInterpolate([{ x: 0, y: 0 }, { x: 10, y: 20 }], 11)).toBeNull()
    expect(findCrossing([0, 1, 2], [0, 1, 2], [1.5, 1.5, 1.5])).toBeCloseTo(1.5, 12)
  })
  it("lê números pt-BR", () => {
    expect(parseLocaleNumber("1.234,56")).toBeCloseTo(1234.56, 12)
    expect(parseLocaleNumber("0,003")).toBeCloseTo(0.003, 12)
    expect(parseLocaleNumber("abc")).toBeNaN()
  })
})
