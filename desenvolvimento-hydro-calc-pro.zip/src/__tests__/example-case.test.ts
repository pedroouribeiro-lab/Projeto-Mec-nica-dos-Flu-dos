import { describe, expect, it } from "vitest"
import { criarCasoAdicional, criarCasoExemplo } from "@/data/example-case"
import { compareResults } from "@/services/comparison"
import { computeSystem } from "@/utils/system"

const TOL = 0.005

function expectClose(actual: number, expected: number, tol = TOL) {
  const rel = Math.abs(actual - expected) / Math.abs(expected)
  expect(rel, `esperado ${expected}, obtido ${actual}`).toBeLessThanOrEqual(tol)
}

describe("Caso de exemplo — condição base (Colebrook)", () => {
  const r = computeSystem(criarCasoExemplo())

  it("vazão em m³/s", () => expectClose(r.vazaoM3s, 0.008333))
  it("velocidades", () => {
    expectClose(r.succao.velocidade, 1.658)
    expectClose(r.recalque.velocidade, 2.511)
  })
  it("Reynolds e regime turbulento", () => {
    expectClose(r.succao.reynolds, 45757)
    expectClose(r.recalque.reynolds, 56316)
    expect(r.succao.regime).toBe("turbulento")
    expect(r.recalque.regime).toBe("turbulento")
  })
  it("fator de atrito", () => {
    expectClose(r.succao.atrito.f, 0.0231)
    expectClose(r.recalque.atrito.f, 0.02273)
    expect(r.succao.atrito.convergiu).toBe(true)
  })
  it("ΣK", () => {
    expectClose(r.succao.somaK, 4.45)
    expectClose(r.recalque.somaK, 19.45)
  })
  it("perdas totais", () => {
    expectClose(r.succao.perdaTotal, 1.432)
    expectClose(r.recalque.perdaTotal, 18.618)
  })
  it("altura manométrica", () => expectClose(r.altura.total, 37.25))
  it("potências", () => {
    expectClose(r.potencia.hidraulicaW / 1000, 3.15)
    expectClose(r.potencia.eixoW / 1000, 4.64)
    expectClose(r.potencia.eletricaW / 1000, 5.21)
  })
  it("energia e custo", () => {
    expectClose(r.potencia.energiaMensalKWh, 3125)
    expectClose(r.potencia.custoMensal, 2625)
  })
  it("NPSH", () => {
    expectClose(r.npsh.npsha, 9.12)
    expectClose(r.npsh.margem, 4.12)
    expectClose(r.npsh.razao, 1.82)
    expect(r.npsh.status).toBe("seguro")
  })
})

describe("Caso de exemplo — cenário adicional (K válvula = 25)", () => {
  const base = computeSystem(criarCasoExemplo())
  const r = computeSystem(criarCasoAdicional())

  it("ΣK e perda no recalque", () => {
    expectClose(r.recalque.somaK, 34.45)
    expectClose(r.recalque.perdaTotal, 23.439)
  })
  it("altura e potências", () => {
    expectClose(r.altura.total, 42.07)
    expectClose(r.potencia.eixoW / 1000, 5.23)
    expectClose(r.potencia.eletricaW / 1000, 5.88)
    expectClose(r.potencia.custoMensal, 2964)
  })
  it("NPSHA inalterado", () => {
    expectClose(r.npsh.npsha, 9.12)
    expect(r.npsh.npsha).toBeCloseTo(base.npsh.npsha, 12)
  })
  it("interpretação cita NPSHA inalterado", () => {
    const c = compareResults(base, r)
    expect(c.interpretacao.some((t) => t.includes("inalterado"))).toBe(true)
    const npshrRow = c.linhas.find((l) => l.chave === "NPSHR")
    expect(npshrRow?.variacaoPct).toBe(0)
  })
})
