import type { Material } from "@/types"

export const MATERIAL_ACO_COMERCIAL: Material = {
  id: "material-aco-comercial",
  nome: "Aço comercial",
  epsilon: 0.045,
  fonte: "Dados do caso de projeto (enunciado); valor usual tabelado para aço comercial novo.",
}

export const MATERIAIS_PADRAO: Material[] = [MATERIAL_ACO_COMERCIAL]
