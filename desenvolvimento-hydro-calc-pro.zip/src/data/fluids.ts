import type { Fluid } from "@/types"

export const FLUIDO_ETILENOGLICOL_30: Fluid = {
  id: "fluido-etilenoglicol-30",
  nome: "Solução de etilenoglicol 30% (massa)",
  temperaturaC: 25,
  rho: 1035,
  mu: 0.003,
  pv: 2.3,
  fonte: "Dados do caso de projeto (enunciado). Confirmar com ficha técnica do fornecedor.",
}

export const FLUIDOS_PADRAO: Fluid[] = [FLUIDO_ETILENOGLICOL_30]
