import type { PumpCurvePoint, Settings, SystemInput } from "@/types"
import { FLUIDO_ETILENOGLICOL_30 } from "./fluids"
import { MATERIAL_ACO_COMERCIAL } from "./materials"

export const CONFIGURACOES_PADRAO: Settings = {
  g: 9.81,
  metodoAtrito: "colebrook",
  limiarSeguro: 1.3,
  limiarLimitrofe: 1.0,
  vMaxSuccao: 2.0,
  vMaxRecalque: 3.0,
  reLaminar: 2300,
  reTurbulento: 4000,
  rugRelMax: 0.05,
}

export const NOME_VALVULA_CONTROLE = "Válvula globo/controle"

export function criarCasoExemplo(): SystemInput {
  return {
    fluido: { ...FLUIDO_ETILENOGLICOL_30 },
    vazaoM3h: 30,
    p0KPaAbs: 101.3,
    p2KPaAbs: 101.3,
    z0: 0.8,
    z2: 18.0,
    zBomba: 0,
    succao: {
      diametroMm: 80,
      comprimentoM: 20,
      materialOuEpsilonMm: MATERIAL_ACO_COMERCIAL.epsilon,
      materialNome: MATERIAL_ACO_COMERCIAL.nome,
      singularidades: [
        { nome: "Entrada", quantidade: 1, kUnitario: 0.5 },
        { nome: "Cotovelo 90°", quantidade: 2, kUnitario: 0.9 },
        { nome: "Válvula gaveta", quantidade: 1, kUnitario: 0.15 },
        { nome: "Filtro", quantidade: 1, kUnitario: 2.0 },
      ],
    },
    recalque: {
      diametroMm: 65,
      comprimentoM: 110,
      materialOuEpsilonMm: MATERIAL_ACO_COMERCIAL.epsilon,
      materialNome: MATERIAL_ACO_COMERCIAL.nome,
      singularidades: [
        { nome: "Cotovelo 90°", quantidade: 7, kUnitario: 0.9 },
        { nome: "Válvula gaveta", quantidade: 1, kUnitario: 0.15 },
        { nome: "Válvula de retenção", quantidade: 1, kUnitario: 2.0 },
        { nome: NOME_VALVULA_CONTROLE, quantidade: 1, kUnitario: 10.0 },
        { nome: "Saída", quantidade: 1, kUnitario: 1.0 },
      ],
    },
    etaBomba: 0.68,
    etaMotor: 0.89,
    npshr: 5.0,
    horasDia: 20,
    diasMes: 30,
    tarifaKWh: 0.84,
    g: 9.81,
    metodoAtrito: "colebrook",
  }
}

export function criarCasoAdicional(): SystemInput {
  const base = criarCasoExemplo()
  return {
    ...base,
    recalque: {
      ...base.recalque,
      singularidades: base.recalque.singularidades.map((s) =>
        s.nome === NOME_VALVULA_CONTROLE ? { ...s, kUnitario: 25.0 } : s,
      ),
    },
  }
}

/**
 * Curva de bomba ilustrativa para demonstrar o cálculo do ponto de operação.
 * Não corresponde a um modelo comercial: substitua pelos dados do fabricante.
 */
export const CURVA_BOMBA_ILUSTRATIVA: PumpCurvePoint[] = [
  { vazaoM3h: 0, alturaM: 48, etaPct: 0, npshrM: 2.5 },
  { vazaoM3h: 10, alturaM: 47, etaPct: 42, npshrM: 3.0 },
  { vazaoM3h: 20, alturaM: 44.5, etaPct: 60, npshrM: 3.8 },
  { vazaoM3h: 30, alturaM: 40, etaPct: 68, npshrM: 5.0 },
  { vazaoM3h: 40, alturaM: 33, etaPct: 66, npshrM: 6.6 },
  { vazaoM3h: 45, alturaM: 28.5, etaPct: 60, npshrM: 7.6 },
]
