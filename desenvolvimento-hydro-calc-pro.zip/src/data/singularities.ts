import type { Singularity } from "@/types"

/**
 * Coeficientes K de referência usados no caso de projeto.
 * Valores reais dependem do fabricante e do diâmetro: sempre confirmar.
 */
export const SINGULARIDADES_REFERENCIA: Array<Pick<Singularity, "nome" | "kUnitario">> = [
  { nome: "Entrada", kUnitario: 0.5 },
  { nome: "Cotovelo 90°", kUnitario: 0.9 },
  { nome: "Válvula gaveta", kUnitario: 0.15 },
  { nome: "Filtro", kUnitario: 2.0 },
  { nome: "Válvula de retenção", kUnitario: 2.0 },
  { nome: "Válvula globo/controle", kUnitario: 10.0 },
  { nome: "Saída", kUnitario: 1.0 },
]
